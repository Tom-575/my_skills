/* ============================================================
   AI 学习导师 · 知识工作台 v4（小白向导）
   目标：让第一次用的人，不用看说明也能做完。
   改内容的动作只有三种：
     ① 自己改（双击文字直接编辑）
     ② 重新生成（一键，AI 从头写一版）
     ③ 按指示生成（输入一句话，AI 按这句话重做选中的部分）
   没有版本控制、没有候选队列、没有 diff；改错了就「撤销」。
   ============================================================ */

const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const now = () => { const d = new Date(); return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`; };

/* ---------------- 资料 ---------------- */
const DOCS = [
  { id:'d3', n:'SOP-ME-017 注塑机常见故障排查作业指导书', k:'SOP', v:'V3.2', seg:5,
    blocks:[
      { a:'4.2·p1', h:'适用范围与作业前要求', t:'适用范围：所有型号注塑机的料筒加热段温度异常报警。作业前必须停机、挂牌上锁（LOTO），并由具备操作资质的人员执行。' },
      { a:'4.2·p2', h:'排查四步法', t:'排查四步法：第一步，记录报警代码与发生时的工艺参数；第二步，检查热电偶接线与插入深度，用万用表测量阻值；第三步，检查加热圈是否断路或接地，测各段电流；第四步，检查冷却水路与温控表参数。' },
      { a:'4.2·p3', h:'根因概率排序', t:'常见根因排序（按历史工单统计）：热电偶松动或老化 42%、加热圈损坏 28%、冷却水路结垢 15%、温控表 PID 参数漂移 10%、其他 5%。' },
      { a:'4.2·p4', h:'处理与闭环', t:'处理完成后须填写《设备异常处理单》，注明报警代码、根因、更换配件编号与处理结果，并在 MES 系统中闭环工单。未闭环的工单不得跨班次移交。' },
      { a:'4.2·q1', h:'安全提示', t:'严禁在带电状态下拆卸加热圈接线端子；料筒高温区作业必须佩戴隔热手套与护目镜。' }
    ]},
  { id:'d4', n:'注塑成型工艺与设备维护 · 第 4 章（培训课件）', k:'PPT', v:'2026-09-02', seg:2,
    blocks:[
      { a:'p1', h:'第 18 页 · 温控系统组成', t:'料筒温控系统由四部分组成：热电偶（感知）、加热圈（执行）、温控表 / PLC（决策）、冷却水路（散热）。任一环节失效都会表现为温度异常。' },
      { a:'p2', h:'第 19 页 · 闭环与排查顺序', t:'理解这个闭环后，故障排查就有了顺序：先确认感知是否准确，再确认执行是否到位，最后看决策参数与散热条件。' }
    ]},
  { id:'d7', n:'视频：注塑机结构原理与常见故障（第 3 讲）', k:'视频', v:'ME-203', seg:2,
    blocks:[
      { a:'p1', h:'00:00–08:20 结构拆解', t:'料筒与螺杆的结构拆解；08:20–20:40 加热圈与热电偶的工作原理与拆装演示。' },
      { a:'p2', h:'24:15–26:40 三类失效实拍', t:'讲师用三台实机演示了热电偶松动、加热圈断路、水路结垢三种失效对应的温度曲线形态。' }
    ]}
];

/* ---------------- 产出：知识点 ---------------- */
let KPS = [
  { id:'k1', t:'温控系统组成与闭环', dom:'设备结构认知',
    def:'料筒温控系统由感知、执行、决策、散热四个环节组成，任一环节失效都会表现为温度异常。',
    pts:['热电偶负责感知温度，加热圈负责执行加热','温控表 / PLC 负责决策，冷却水路负责散热','理解这个闭环，就理解 SOP 排查顺序为什么这样排'],
    srcs:[['d4','p1','课件 p18'],['d7','p1','视频 00:00–08:20']] },
  { id:'k2', t:'温度异常排查四步法', dom:'故障排查',
    def:'按 SOP-ME-017 第 4.2 节的固定顺序排查：先记录、再查感知、再查执行、最后查散热与参数，不得凭经验跳步。',
    pts:['第一步：记录报警代码与当时的工艺参数','第二步：检查热电偶接线与插入深度，用万用表测阻值','第三步：检查加热圈是否断路或接地，测各段电流','第四步：检查冷却水路与温控表 PID 参数'],
    srcs:[['d3','4.2·p2','SOP 四步法'],['d4','p2','为什么这个顺序']] },
  { id:'k3', t:'热电偶故障根因与排查优先级', dom:'故障排查',
    def:'按历史工单统计，热电偶松动或老化占 42%，优先检查热电偶可覆盖近半数场景。',
    pts:['热电偶松动或老化 42%、加热圈损坏 28%','水路结垢 15%、PID 漂移 10%、其他 5%','先查热电偶，是最省时间的顺序'],
    srcs:[['d3','4.2·p3','根因排序'],['d7','p2','实拍对照']] },
  { id:'k4', t:'挂牌上锁 LOTO 要求', dom:'安全规范', lv:1, lock:1,
    def:'作业前必须停机、挂牌上锁（LOTO），并由具备操作资质的人员执行，无例外。',
    pts:['停机 → 挂牌 → 上锁，三步缺一不可','执行人必须持有本岗位操作资质，本人上锁、本人保管钥匙','这是硬性要求，不是建议'],
    srcs:[['d3','4.2·p1','作业前硬要求']] },
  { id:'k5', t:'高温作业防护要求', dom:'安全规范', lv:1, lock:1,
    def:'严禁带电拆卸加热圈接线端子；料筒高温区作业必须佩戴隔热手套与护目镜。',
    pts:['严禁带电拆接线端子','高温区作业必须戴隔热手套与护目镜'],
    srcs:[['d3','4.2·q1','安全提示']] },
  { id:'k6', t:'异常单填写与工单闭环', dom:'故障排查', lv:1,
    def:'处理完成须填写《设备异常处理单》并在 MES 闭环工单，未闭环的工单不得跨班次移交。',
    pts:['写明报警代码、根因、更换配件编号、处理结果','在 MES 中闭环工单','未闭环不得跨班次移交'],
    srcs:[['d3','4.2·p4','处理单要求']] }
];

const KINDS = [
  { id:'kp', ic:'☰', c:'#EFF4FF', fc:'#1D4ED8', n:'生成知识点',
    d:'把资料拆成一个个 30 秒能讲清的知识点，每个都挂回原文。员工在 AI 导师里问到它，就能看到出处。',
    m:[['产出','知识点清单'],['用时','约 20 秒'],['需要','SOP / 课件均可']] },
  { id:'qz', ic:'✓', c:'#F0FDF4', fc:'#16A34A', n:'生成考题',
    d:'按原文出判断题、单选题、填空题、步骤排序题。每题都带参考答案与解析，并绑定出处段落。',
    m:[['产出','一套随堂测验'],['用时','约 15 秒'],['需要','先有知识点']] },
  { id:'pt', ic:'▤', c:'#FFFBEB', fc:'#D97706', n:'生成培训课件',
    d:'把知识点串成能直接讲的幻灯片，带演讲备注，可换配色、导出 PPTX，班前会直接放。',
    m:[['产出','8 页 PPT'],['用时','约 20 秒'],['需要','建议先有知识点']] }
];

/* ---------------- 产出：考题 ----------------
   ans：单选/判断为正确项索引；步骤排序为正确顺序的索引数组；填空题用 blanks
------------------------------------------------ */
let QZ = [
  { id:'q1', ty:'判断题', df:'易', st:'处理料筒加热段温度异常前，必须先停机、挂牌上锁（LOTO）。',
    ops:['正确','错误'], ans:0, why:'SOP-ME-017 第 4.2 节作业前要求，无例外。', src:['d3','4.2·p1','SOP 4.2 作业前要求'] },
  { id:'q2', ty:'单选题', df:'中', st:'按历史工单统计，料筒温度异常最常见的根因是哪一个？',
    ops:['加热圈损坏','热电偶松动或老化','冷却水路结垢','PID 参数漂移'], ans:1,
    why:'热电偶松动或老化占 42%，是第一位。按这个顺序查，能覆盖近半数场景。', src:['d3','4.2·p3','SOP 4.2 根因排序'] },
  { id:'q3', ty:'步骤排序', df:'中', st:'请按 SOP 规定的顺序排列以下排查步骤：',
    ops:['检查热电偶接线与插入深度','记录报警代码与工艺参数','检查冷却水路与温控表参数','检查加热圈是否断路或接地'], ans:[1,0,3,2],
    why:'正确顺序：记录 → 热电偶 → 加热圈 → 水路与参数。这是排查顺序，不是记录顺序。', src:['d3','4.2·p2','SOP 4.2 四步法'] },
  { id:'q4', ty:'单选题', df:'易', st:'温度异常处理完成后，关于工单闭环的说法哪一个是正确的？',
    ops:['口头交接给下一班即可','未闭环的工单不得跨班次移交','等月底统一补录','配件编号可以不填'], ans:1,
    why:'SOP 明确要求：须填写《设备异常处理单》并在 MES 闭环，未闭环不得跨班次移交。', src:['d3','4.2·p4','SOP 4.2 处理与闭环'] },
  { id:'q5', ty:'判断题', df:'中', st:'排查时可以先凭经验直接更换加热圈，不用先记录报警代码。',
    ops:['正确','错误'], ans:1,
    why:'跳步会丢失判断依据。SOP 要求第一步必须记录报警代码与当时的工艺参数。', src:['d3','4.2·p2','SOP 4.2 四步法'] },
  { id:'q6', ty:'填空题', df:'中',
    st:'排查四步法的第二步是检查热电偶的接线与______，并用万用表测量______。',
    blanks:['插入深度','阻值'],
    why:'SOP 原文：检查热电偶接线与插入深度，用万用表测量阻值。两个空都对才算对。', src:['d3','4.2·p2','SOP 4.2 四步法'] },
  { id:'q7', ty:'填空题', df:'易',
    st:'处理完成后必须填写《______》，并在 ______ 系统中闭环工单。',
    blanks:['设备异常处理单','MES'],
    why:'SOP 第 4.2 节处理与闭环要求，两处都是固定写法，不能简写。', src:['d3','4.2·p4','SOP 4.2 处理与闭环'] }
];
const QZ_ALT = {
  q1:{ st:'只要设备已经停止加热，就可以不经挂牌上锁开始拆检。', ops:['正确','错误'], ans:1,
       why:'停止加热不等于能量隔离。LOTO 是硬性要求，与设备当前温度无关。' },
  q2:{ st:'某段温度长期偏低且升温缓慢，最可能的原因是？',
       ops:['该段加热圈损坏','热电偶型号不匹配','PID 比例带过小','料筒保温层过厚'], ans:0,
       why:'升温缓慢、温度偏低是加热圈损坏的典型表现；热电偶故障多表现为跳变或无规律。' },
  q6:{ st:'排查四步法的第三步针对的是______，需要检查它是否断路或接地。', blanks:['加热圈'],
       why:'第三步查加热圈，测各段电流判断是否断路或接地。' }
};
/* 换成填空题的预置版本（其余题型走通用改写） */
const QZ_FILL = {
  q1:{ st:'处理料筒温度异常前，必须先______、______，三步缺一不可。', blanks:['停机','挂牌上锁'],
       why:'SOP 作业前要求：停机 → 挂牌 → 上锁，缺一不可。' },
  q2:{ st:'按历史工单统计，料筒温度异常最常见的根因是______，约占 42%。', blanks:['热电偶松动或老化'],
       why:'根因排序第一位，先查它最省时间。' },
  q3:{ st:'SOP 排查四步：先______，再查热电偶，再查______，最后查冷却水路与 PID 参数。',
       blanks:['记录报警代码与工艺参数','加热圈'],
       why:'这是排查顺序，跳步会丢掉判断依据。' },
  q4:{ st:'温度异常处理完成后，未闭环的工单______跨班次移交。', blanks:['不得'],
       why:'未闭环不得跨班次移交，这是硬性要求。' },
  q5:{ st:'SOP 要求排查的第一步是记录______与当时的工艺参数。', blanks:['报警代码'],
       why:'没有参数记录，后面全是猜。' }
};
const QZ_TYPES = ['判断题','单选题','填空题','步骤排序'];

/* ---------------- 产出：课件 ---------------- */
let SLIDES = [
  { cover:1, t:'注塑机温度异常排查', s:'设备维护岗 · 初级工培训', pts:['依据 SOP-ME-017 V3.2'],
    note:'开场说明本次培训依据的 SOP 版本，提醒员工手上纸质版可能是旧版。' },
  { t:'今天讲三件事', pts:['温控系统是怎么工作的','温度异常怎么查','查完之后怎么收尾'],
    note:'先给框架，让员工知道接下来 20 分钟要听什么。' },
  { t:'温控系统：四个环节', pts:['热电偶 —— 感知温度','加热圈 —— 执行加热','温控表 / PLC —— 决策','冷却水路 —— 散热','坏哪一样，表现都是「温度不对」'],
    note:'这是全程唯一需要记住的结构图。后面的排查顺序就是按这四环节排的。', src:['d4','p1','课件 p18'] },
  { t:'排查四步法', pts:['第一步：记录报警代码与工艺参数','第二步：查热电偶 —— 接线、插入深度、阻值','第三步：查加热圈 —— 断路、接地、电流','第四步：查冷却水路与 PID 参数','不得凭经验跳步'],
    note:'强调顺序不能跳。很多老员工习惯直接换加热圈，跳过记录会丢掉判断依据。', src:['d3','4.2·p2','SOP 四步法'] },
  { t:'先查热电偶，为什么', pts:['热电偶松动或老化 —— 42%','加热圈损坏 —— 28%','水路结垢 —— 15%','PID 漂移 —— 10%','先查它最省时间'],
    note:'用数据说服老员工：这不是拍脑袋排的顺序，是历史工单统计出来的。', src:['d3','4.2·p3','根因排序'] },
  { t:'两条安全红线', pts:['停机 → 挂牌 → 上锁，三步缺一不可','本人上锁、本人保管钥匙','严禁带电拆加热圈接线端子','高温区作业必须戴隔热手套与护目镜'],
    note:'这一页要停下来讲。这两条是强制条款，违反直接按违章处理。', src:['d3','4.2·q1','安全提示'] },
  { t:'修好不等于做完', pts:['填写《设备异常处理单》','写明报警代码、根因、配件编号、处理结果','在 MES 闭环工单','未闭环不得跨班次移交'],
    note:'现场最常见的问题：设备修好了，单子不填、工单不闭环。', src:['d3','4.2·p4','处理单要求'] },
  { t:'小结 · 记住这四句', pts:['温控是个闭环，坏哪样都表现成温度不对','排查四步，顺序不能跳','先查热电偶，十个里有四个是它','安全红线两条，没有例外'],
    note:'收尾。下课前会发小测，答错的题可以点回原文看。' }
];
const SL_ALT = {
  2:{ t:'温控四环节（换个说法）', pts:['测温的：热电偶','加温的：加热圈','拿主意的：PLC','散热的：水路','排查顺序就是这四个的顺序'] },
  4:{ t:'为什么先查热电偶', pts:['历史工单统计：42%','它不是最贵的，但是最常坏的','查它只要一支万用表','先查它，一半的问题就解决了'] },
  5:{ t:'安全红线（清单式）', pts:['□ 停机','□ 挂牌','□ 上锁','□ 戴隔热手套与护目镜','□ 严禁带电拆接线端子'] }
};

const THEMES = [
  { id:'blue',  n:'商务蓝', bg:'#FFFFFF', ac:'#1D4ED8', fg:'#0F172A', soft:'#EFF4FF' },
  { id:'amber', n:'工厂橙', bg:'#FFFCF5', ac:'#D97706', fg:'#451A03', soft:'#FEF3C7' },
  { id:'slate', n:'简约灰', bg:'#F8FAFC', ac:'#334155', fg:'#0F172A', soft:'#E2E8F0' },
  { id:'green', n:'安全绿', bg:'#F6FEF8', ac:'#15803D', fg:'#052E16', soft:'#DCFCE7' }
];

/* 指令词命中后给的真实反馈素材（不是按钮，是 AI 按指令走的结果） */
const ORAL = {
  k1:'说白了，温控就是四件套：热电偶测温、加热圈加温、PLC 拿主意、水路散热。坏哪一样，表现出来都是「温度不对」。',
  k2:'记住四步：先记参数、再查热电偶、再查加热圈、最后看水路和 PID。这个顺序是按故障率排的，跳步就是浪费时间。',
  k3:'先查热电偶，因为十个里有四个是它坏了。先查它最省时间。',
  k6:'修好不等于做完。单子不填、工单不闭环，这事就跨不过班次。'
};
const KP_ALT = {
  k1:{ def:'先问一句：温度为什么会异常？因为温控是个闭环，四个环节坏哪个都表现成温度不对。',
    pts:['感知环节：热电偶 —— 测不准，后面全跟着错','执行环节：加热圈 —— 该加温时没加温','决策环节：温控表 / PLC —— 收到错信号就做错判断','散热环节：冷却水路 —— 该散热时散不掉'] },
  k2:{ def:'换个更实用的讲法：按故障率从高往低查。SOP 的四步法本身就是这么排的，一线记住「先热电偶」就够用。',
    pts:['准备：先记录报警代码与工艺参数','第一查：热电偶（42%）—— 看接线、测阻值','第二查：加热圈（28%）—— 查断路、接地、电流','第三查：冷却水路（15%）—— 看是否结垢','最后查：PID 参数（10%）—— 前三项都正常才动它'] },
  k3:{ def:'为什么要先查热电偶？因为历史工单里 42% 都是它。这个数字决定了排查的性价比。',
    pts:['热电偶松动或老化 42% —— 先看它','加热圈损坏 28% —— 其次','水路结垢 15% —— 再次','PID 漂移 10% —— 最后'] },
  k6:{ def:'修好不等于做完。填单、闭环这两步不做，工单就跨不过班次。',
    pts:['填写《设备异常处理单》：报警代码、根因、配件编号、处理结果','在 MES 中闭环工单','未闭环不得跨班次移交'] }
};
const SUGGEST = [
  { t:'PID 参数整定基础', why:'课件第 21 页讲了比例带与积分时间，目录里没有对应的一节。',
    def:'比例带过大导致响应慢，过小导致温度振荡；现场一般用厂家默认值。',
    pts:['比例带：过大响应慢，过小温度振荡','积分时间：过短易超调','仅在更换加热圈规格后才需重新整定'],
    srcs:[['d4','p1','课件 p21']] },
  { t:'温度曲线怎么读', why:'视频 24:15 起演示了三种失效的曲线形态，可作为排查判据。',
    def:'不同失效对应不同曲线形态，看曲线能提前判断大致方向。',
    pts:['热电偶松动：温度跳变、无规律','加热圈断路：温度持续走低','水路结垢：温度缓慢爬升'],
    srcs:[['d7','p2','视频 24:15']] }
];

/* ---------------- 状态 ---------------- */
let step = 1, kind = null, picked = ['d3','d4','d7'], TH = 'blue';
let selKp = null, selQ = null, selSl = 0, slMul = [0], showAns = true;
let busy = null, busySl = [], undoSnap = null, genTimer = null;

/* ============================================================
   步骤切换
   ============================================================ */
const STEP_N = ['选要做什么','给资料','AI 生成','看结果'];
function renderSteps(){
  $('#steps').innerHTML = STEP_N.map((n, i) => {
    const k = i + 1;
    const cls = k === step ? 'on' : (k < step ? 'done' : '');
    const mark = k < step ? '✓' : k;
    return (i ? '<span class="st-ln"></span>' : '') +
      `<span class="st ${cls}"><span class="st-n">${mark}</span>${n}</span>`;
  }).join('');
  $('#restart').hidden = step === 1;
  $('#bottom').hidden = step !== 4;
}
function go(n){
  step = n;
  document.querySelectorAll('.step').forEach(s => s.classList.toggle('on', +s.dataset.step === n));
  renderSteps();
  if (n === 1) renderKinds();
  if (n === 2) renderDocs();
  if (n === 3) runGen();
  if (n === 4) renderResult();
}

/* ============================================================
   第 1 步：选要做什么
   ============================================================ */
function renderKinds(){
  $('#kinds').innerHTML = KINDS.map(k => `
    <button class="kind${kind === k.id ? ' on' : ''}" data-kind="${k.id}">
      <span class="k-ic" style="background:${k.c};color:${k.fc}">${k.ic}</span>
      <span class="k-n">${k.n}</span>
      <span class="k-d">${esc(k.d)}</span>
      <span class="k-meta">${k.m.map(m => `<span><b>${m[0]}</b> ${m[1]}</span>`).join('')}</span>
    </button>`).join('');
}
$('#kinds').addEventListener('click', e => {
  const b = e.target.closest('[data-kind]'); if (!b) return;
  kind = b.dataset.kind; renderKinds();
  setTimeout(() => go(2), 160);
});

/* ============================================================
   第 2 步：给资料
   ============================================================ */
function renderDocs(){
  const list = DOCS;
  $('#docCount').textContent = `已选 ${picked.length} / ${list.length} 份 · 共 ${list.filter(d => picked.includes(d.id)).reduce((n, d) => n + d.seg, 0)} 段原文`;
  $('#docs').innerHTML = list.map(d => `
    <div class="dc${picked.includes(d.id) ? ' on' : ''}" data-doc="${d.id}">
      <span class="ck">✓</span>
      <span class="dc-i">${d.k}</span>
      <span class="dc-n">${esc(d.n)}</span>
      <span class="dc-v">${d.v}</span>
      <span class="dc-s">${d.seg} 段</span>
    </div>`).join('');
  const n = picked.length;
  const kd = KINDS.find(k => k.id === kind);
  $('#doGen').disabled = n === 0 || !kd;
  $('#goTip').textContent = !kd ? '请先回到上一步选要做什么'
    : n === 0 ? '至少选 1 份资料'
    : kd.n + ' · 预计 ' + (kind === 'qz' ? QZ.length + ' 道题' : kind === 'pt' ? SLIDES.length + ' 页' : (n * 2) + ' 个知识点');
}
$('#docs').addEventListener('click', e => {
  const d = e.target.closest('[data-doc]'); if (!d) return;
  const id = d.dataset.doc;
  if (picked.includes(id)) picked = picked.filter(x => x !== id); else picked.push(id);
  renderDocs();
});
$('#up').addEventListener('click', () => {
  toast('原型里没有接真实上传 —— 直接勾选下面已有的 3 份就行');
});
$('#doGen').addEventListener('click', () => { if (picked.length) go(3); });

/* ============================================================
   第 3 步：生成中
   ============================================================ */
const LOGS = {
  kp: () => [
    '读取 SOP-ME-017 V3.2 · 切出 5 个段落',
    '读取课件第 4 章 · 切出 2 个段落',
    '读取视频 ME-203 · 定位 2 个时间区间',
    '抽出 11 个候选知识点',
    '合并重复项 5 个 —— SOP 与课件讲的是同一件事',
    '标注 3 处强制条款 · 这部分不会改写原文',
    '给每个知识点挂上原文出处',
    `完成：${KPS.length} 个知识点，${KPS.reduce((n, s) => n + s.srcs.length, 0)} 处引用`
  ],
  qz: () => [
    `加载 ${KPS.length} 个知识点与 9 段原文`,
    `按考点分布命题：判断 ${QZ.filter(q=>q.ty==='判断题').length} · 单选 ${QZ.filter(q=>q.ty==='单选题').length} · 填空 ${QZ.filter(q=>q.ty==='填空题').length} · 排序 ${QZ.filter(q=>q.ty==='步骤排序').length}`,
    '填空题优先挖关键参数与固定写法，避免只考记忆',
    '每道题都生成参考答案与解析',
    '每题绑定出处段落',
    `完成：${QZ.length} 道题`
  ],
  pt: () => [
    `读取 ${KPS.length} 个知识点，按讲课逻辑重排`,
    '生成页面结构：封面 + 目录 + 5 个正节 + 小结',
    '把知识点改写成能念出来的讲稿',
    '为每页补演讲备注',
    '套用配色：商务蓝',
    `完成：${SLIDES.length} 页`
  ]
};
function runGen(){
  const lines = (LOGS[kind] || LOGS.kp)();
  const total = lines.length;
  let i = 0;
  $('#log').innerHTML = '';
  const titles = { kp:'正在拆知识点', qz:'正在出题', pt:'正在做课件' };
  $('#genT').textContent = titles[kind] || '正在准备…';
  clearInterval(genTimer);
  genTimer = setInterval(() => {
    if (i < total){
      const done = i === total - 1;
      $('#log').insertAdjacentHTML('beforeend',
        `<div class="lg"><span class="lg-t">${now()}</span><span class="lg-c">${done ? '<b>' + esc(lines[i]) + '</b>' : esc(lines[i])}</span></div>`);
      i++;
      const p = Math.round(i / total * 100);
      $('#genP').textContent = p + '%';
      $('#genBar').style.width = p + '%';
      $('#genS').textContent = '第 ' + i + ' / ' + total + ' 步';
      $('#log').scrollTop = 99999;
    } else {
      clearInterval(genTimer);
      setTimeout(() => { selKp = null; selQ = null; selSl = 0; slMul = [0]; showAns = true; go(4); }, 520);
    }
  }, 420);
}

/* ============================================================
   第 4 步：结果
   ============================================================ */
function renderResult(){
  expU = 'use'; expF = null; expPart = false;
  const et = $('#editTip'); if (et) et.hidden = false;
  $('#resKp').hidden = kind !== 'kp';
  $('#resQz').hidden = kind !== 'qz';
  $('#resPt').hidden = kind !== 'pt';
  if (kind === 'kp'){ renderOutline(); renderDoc(); renderRight(); }
  if (kind === 'qz'){ renderQuiz(); renderRightQ(); }
  if (kind === 'pt'){ renderThemes(); renderSlList(); renderSlides(); renderRightP(); }
  const info = {
    kp:`${KPS.length} 个知识点 · 已挂 ${KPS.reduce((n, s) => n + s.srcs.length, 0)} 处原文`,
    qz:`${QZ.length} 道题 · 全部带参考答案与出处`,
    pt:`${SLIDES.length} 页 · 每页带演讲备注`
  };
  $('#boInfo').textContent = KINDS.find(k => k.id === kind).n + ' · ' + info[kind];
}

/* ============================================================
   知识点视图 —— 改内容只有三种动作
   ============================================================ */
function renderOutline(){
  $('#olCount').textContent = KPS.length + ' 节';
  $('#outline').innerHTML = KPS.map((s, i) => `
    <div class="ol-i${selKp === s.id ? ' on' : ''}" data-ol="${s.id}">
      <span class="ol-n">${i + 1}</span>
      <span class="ol-t" data-ed="${s.id}">${esc(s.t)}</span>
      ${s.lv ? '<span class="bdg lv">强制</span>' : ''}
      <span class="ol-up">
        <button class="ol-btn" data-up="${s.id}" title="上移">↑</button>
        <button class="ol-btn" data-dn="${s.id}" title="下移">↓</button>
        <button class="ol-btn del" data-rm="${s.id}" title="删除">×</button>
      </span>
    </div>`).join('');
}
function renderDoc(){
  $('#docMeta').textContent = `${KPS.length} 节 · 已挂 ${KPS.reduce((n, s) => n + s.srcs.length, 0)} 处原文 · ✎ 文字可直接双击修改`;
  $('#docScroll').innerHTML = '<div class="doc">' + KPS.map((s, i) => {
    if (busy === s.id) return `<div class="sec on">
      <div class="sec-h"><span class="sec-no">${i + 1}</span><span class="sec-t">${esc(s.t)}</span></div>
      <div class="sk" style="width:92%"></div><div class="sk" style="width:76%"></div>
      <div class="sk" style="width:84%"></div><div class="sk" style="width:58%"></div></div>`;
    return `<div class="sec${selKp === s.id ? ' on' : ''}" data-sec="${s.id}">
      <div class="sec-h">
        <span class="sec-no">${i + 1}</span>
        <span class="sec-t">${esc(s.t)}</span>
        ${s.lv ? '<span class="bdg lv">强制</span>' : `<span class="bdg">${esc(s.dom)}</span>`}
        ${s.lock ? '<span class="bdg lock">原文锁定</span>' : ''}
        <span class="sec-acts">
          <button class="mini edt" data-editgo="${s.id}">✎ 改文字</button>
          <button class="mini" data-re="${s.id}">${s.lock ? 'AI 能做什么' : '重新生成'}</button>
        </span>
      </div>
      <div class="sec-def ed" data-edit="${s.id}|def">${esc(s.def)}</div>
      <ul class="sec-pts">${s.pts.map((p, j) =>
        `<li class="pt ed" data-edit="${s.id}|pt|${j}">${esc(p)}</li>`).join('')}</ul>
      <button class="add-pt" data-addpt="${s.id}">＋ 加一条</button>
      <div class="sec-foot">${s.srcs.map(x => `<span class="chip" data-tip="${x[0]}|${x[1]}">${esc(x[2])}</span>`).join('')}</div>
    </div>`;
  }).join('') + '</div>';
}
function renderRight(){
  const s = selKp ? KPS.find(x => x.id === selKp) : null;
  $('#right').classList.toggle('hide', !s);
  if (!s){
    $('#rw').innerHTML = `<div class="rw-empty"><b>先点左边目录，或中间任意一节</b>
      选中后这里只有两个按钮：<b>重新生成</b>、<b>按指示生成</b>。<br><br>
      想自己改？直接在中间<b>双击文字</b>就能编辑，不用进这里。</div>`;
    return;
  }
  if (s.lock){
    $('#rw').innerHTML = `
      <div class="rw-sel"><div class="rw-sel-t">已选中</div><div class="rw-sel-n">${esc(s.t)}</div></div>
      <div class="note warn"><b>这是安全红线，AI 不会改它的字。</b><br>
        改了出了事没人担得起。它只能做下面两件事。</div>
      <div class="rw-lb">可以做的</div>
      <div class="cmds">
        <button class="cmd" data-lk="qa"><b>生成配套判断题</b><span>按原文命题，不改原文</span></button>
        <button class="cmd" data-lk="note"><b>加一条现场提醒</b><span>另起说明，不动条款正文</span></button>
      </div>`;
    return;
  }
  $('#rw').innerHTML = `
    <div class="rw-sel"><div class="rw-sel-t">已选中</div><div class="rw-sel-n">${esc(s.t)}</div></div>
    <button class="rw-main" id="reKp">重新生成这一节</button>
    <div class="rw-lb">或告诉 AI 怎么改</div>
    <textarea class="rw-in" id="rwIn" rows="3" placeholder="例：只讲热电偶，压成 3 条，加一个现场案例"></textarea>
    <button class="rw-go" id="rwGo">按指示生成</button>
    <div class="rw-tip">不想等 AI？直接在中间双击文字自己改，改完点空白处保存。</div>`;
}

/* ---------- 知识点：目录 ---------- */
$('#outline').addEventListener('click', e => {
  const up = e.target.closest('[data-up]'), dn = e.target.closest('[data-dn]'), rm = e.target.closest('[data-rm]');
  if (up || dn || rm){
    const el = up || dn || rm;
    const id = el.dataset.up || el.dataset.dn || el.dataset.rm;
    const i = KPS.findIndex(x => x.id === id);
    if (i < 0) return;
    undoSnap = snapshot();
    if (up && i > 0){ const n = KPS[i].t; [KPS[i - 1], KPS[i]] = [KPS[i], KPS[i - 1]]; toast('已上移：' + n); }
    else if (dn && i < KPS.length - 1){ const n = KPS[i].t; [KPS[i + 1], KPS[i]] = [KPS[i], KPS[i + 1]]; toast('已下移：' + n); }
    else if (rm){ const n = KPS[i].t; KPS.splice(i, 1); if (selKp === id) selKp = null; toast('已删除：' + n); }
    else { undoSnap = null; return; }
    renderOutline(); renderDoc(); renderRight(); return;
  }
  const it = e.target.closest('[data-ol]');
  if (it && !e.target.hasAttribute('data-ed')){
    selKp = it.dataset.ol;
    renderOutline(); renderDoc(); renderRight();
    const el = document.querySelector(`[data-sec="${selKp}"]`);
    if (el) el.scrollIntoView({ behavior:'smooth', block:'center' });
  }
});
$('#outline').addEventListener('dblclick', e => {
  const t = e.target.closest('[data-ed]'); if (!t) return;
  startEdit(t);
});
$('#outline').addEventListener('blur', e => {
  const t = e.target.closest && e.target.closest('[data-ed]'); if (!t) return;
  if (t.getAttribute('contenteditable') !== 'true') return;
  endEdit(t, v => {
    const s = KPS.find(x => x.id === t.dataset.ed);
    if (s && v && v !== s.t){ undoSnap = snapshot(); s.t = v; toast('已改名：' + v); }
  });
}, true);

/* ---------- 知识点：正文直接编辑 ---------- */
function startEdit(el){
  el.setAttribute('contenteditable', 'true');
  el.classList.add('editing');
  el.focus();
  try {
    const r = document.createRange(); r.selectNodeContents(el);
    const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
  } catch(_){ /* 无 Selection API 时忽略 */ }
}
function endEdit(el, save){
  el.setAttribute('contenteditable', 'false');
  el.classList.remove('editing');
  save(el.textContent.trim());
  renderOutline(); renderDoc(); renderRight();
}
$('#docScroll').addEventListener('dblclick', e => {
  const t = e.target.closest('[data-edit]'); if (!t) return;
  e.preventDefault();
  startEdit(t);
});
$('#docScroll').addEventListener('blur', e => {
  const t = e.target.closest && e.target.closest('[data-edit]'); if (!t) return;
  if (t.getAttribute('contenteditable') !== 'true') return;
  const [id, f, i] = t.dataset.edit.split('|');
  endEdit(t, v => {
    const s = KPS.find(x => x.id === id); if (!s) return;
    if (f === 'def'){
      if (!v) return;
      if (v !== s.def){ undoSnap = snapshot(); s.def = v; toast('已保存'); }
    } else {
      const k = +i;
      if (!v){
        if (s.pts.length > 1){ undoSnap = snapshot(); s.pts.splice(k, 1); toast('已删除一条'); }
        return;
      }
      if (v !== s.pts[k]){ undoSnap = snapshot(); s.pts[k] = v; toast('已保存'); }
    }
  });
}, true);
$('#docScroll').addEventListener('keydown', e => {
  if (!e.target.hasAttribute || !e.target.hasAttribute('data-edit')) return;
  if (e.key === 'Enter'){ e.preventDefault(); e.target.blur(); }
  else if (e.key === 'Escape'){
    e.preventDefault();
    e.target.setAttribute('contenteditable', 'false');
    e.target.classList.remove('editing');
    e.target.blur();
    renderDoc(); toast('已取消修改');
  }
});
$('#editTipX').addEventListener('click', () => { $('#editTip').hidden = true; });

/* ---------- 知识点：内容交互 ---------- */
$('#docScroll').addEventListener('click', e => {
  const eg = e.target.closest('[data-editgo]');
  if (eg){
    selKp = eg.dataset.editgo;
    renderOutline(); renderDoc();
    const el = document.querySelector(`[data-edit="${selKp}|def"]`);
    if (el){ startEdit(el); el.scrollIntoView({ behavior:'smooth', block:'center' }); }
    return;
  }
  const add = e.target.closest('[data-addpt]');
  if (add){
    const s = KPS.find(x => x.id === add.dataset.addpt);
    if (s){
      undoSnap = snapshot();
      s.pts.push('新的要点（双击修改）');
      renderDoc();
      const li = document.querySelectorAll(`[data-edit^="${s.id}|pt|"]`);
      if (li.length){ const last = li[li.length - 1]; startEdit(last); }
    }
    return;
  }
  const re = e.target.closest('[data-re]');
  if (re){
    selKp = re.dataset.re;
    const s = KPS.find(x => x.id === selKp);
    renderOutline(); renderDoc(); renderRight();
    if (s.lock) toast('这是强制条款，AI 不改它的字 —— 看右边能做什么');
    else runKp(selKp, null);
    return;
  }
  const sec = e.target.closest('[data-sec]');
  if (sec && !e.target.hasAttribute('data-edit')){ selKp = sec.dataset.sec; renderOutline(); renderDoc(); renderRight(); }
});
$('#rw').addEventListener('click', e => {
  if (e.target.id === 'reKp'){ runKp(selKp, null); return; }
  const lk = e.target.closest('[data-lk]');
  if (lk){
    const s = KPS.find(x => x.id === selKp);
    if (lk.dataset.lk === 'qa') toast('已按原文生成 2 道判断题（未改动原文）');
    else { undoSnap = snapshot(); s.pts = s.pts.concat(['现场提醒：拆检前先确认本段已完全冷却，避免烫伤']); renderDoc(); toast('已加一条现场提醒（条款正文未动）'); }
    return;
  }
  if (e.target.id === 'rwGo'){
    const v = (($('#rwIn') || {}).value || '').trim();
    runKp(selKp, v || '整体重写一版');
  }
});
/* 按指令生成知识点：命中关键词给真反馈，没有就走预设备选 */
function applyKpInst(s, inst){
  const t = inst || '';
  if (/3\s*条|三条|压缩|精简|短一点/.test(t)){
    s.pts = s.pts.slice(0, 3);
    s.def = s.def.length > 60 ? s.def.slice(0, 58) + '…' : s.def;
    return '已压成 3 条';
  }
  if (/案例|例子|现场/.test(t)){
    s.pts = s.pts.concat(['案例：3 号线 8 月因热电偶插头氧化导致温度跳变，紧固后恢复']);
    return '已补一个现场案例';
  }
  if (/口语|听得懂|通俗|白话/.test(t)){
    s.def = ORAL[s.id] || s.def;
    return '已改得更口语';
  }
  if (/清单|打勾|贴|打印/.test(t)){
    s.pts = s.pts.map(p => '□ ' + p.replace(/^□\s*/, ''));
    return '已改成清单式（可直接打印）';
  }
  const a = KP_ALT[s.id];
  if (a){ s.def = a.def; s.pts = a.pts.slice(); return '已换一版讲法'; }
  s.def = s.def + '（已按指示重写）';
  return '已按指示重写';
}
function runKp(id, inst){
  const s = KPS.find(x => x.id === id); if (!s) return;
  undoSnap = snapshot();
  busy = id; renderDoc();
  $('#genTag').hidden = false;
  $('#genTag').textContent = 'AI 正在改「' + s.t + '」…';
  setTimeout(() => {
    const msg = inst ? applyKpInst(s, inst) : (KP_ALT[s.id] ? '已重新生成' : '已重新生成（换了种讲法）');
    if (!inst){
      const a = KP_ALT[s.id];
      if (a){ s.def = a.def; s.pts = a.pts.slice(); }
      else { s.def = s.def + '（重新生成版）'; }
    }
    busy = null;
    $('#genTag').hidden = true;
    renderDoc(); renderRight();
    toast(msg + '：' + s.t);
  }, 1000);
}

/* ============================================================
   考题视图
   ============================================================ */
const AK = 'ABCDE';
function ansText(q){
  if (q.ty === '填空题') return (q.blanks || []).join('　/　');
  if (Array.isArray(q.ans)) return q.ans.map(i => q.ops[i]).join(' → ');
  const ops = q.ty === '判断题' ? ['正确','错误'] : q.ops;
  return ops[q.ans];
}
function renderQuiz(){
  const cnt = ty => QZ.filter(q => q.ty === ty).length;
  $('#qzMeta').textContent = `${QZ.length} 道题 · 判断 ${cnt('判断题')} · 单选 ${cnt('单选题')} · 填空 ${cnt('填空题')} · 排序 ${cnt('步骤排序')} · 全部带参考答案`;
  $('#showAns').classList.toggle('on', showAns);
  $('#showAns').textContent = showAns ? '隐藏答案' : '显示答案';
  $('#qzScroll').innerHTML = '<div class="qz">' + QZ.map((q, i) => {
    const ops = q.ty === '判断题' ? ['正确','错误'] : q.ops;
    /* 填空题：把 ______ 高亮；其余题型按选项渲染 */
    const stem = q.ty === '填空题'
      ? esc(q.st).replace(/______/g, '<span class="blank">______</span>')
      : esc(q.st);
    const rightIdx = Array.isArray(q.ans) ? q.ans : [q.ans];
    return `<div class="q${selQ === q.id ? ' on' : ''}" data-q="${q.id}">
      <div class="q-h">
        <span class="q-no">${i + 1}</span>
        <span class="q-ty">${q.ty}</span>
        <span class="q-df">${q.df}</span>
      </div>
      <div class="q-st">${stem}</div>
      ${q.ty === '填空题'
        ? `<div class="q-blanks">${(q.blanks || []).length} 个空</div>`
        : `<ul class="q-op">${ops.map((o, j) =>
            `<li class="op${showAns && rightIdx.indexOf(j) >= 0 ? ' right' : ''}" data-k="${AK[j]}">${esc(o)}</li>`).join('')}</ul>`}
      ${showAns ? `<div class="q-ans">
        <div class="q-ans-h">参考答案</div>
        <div class="q-ans-v">${esc(ansText(q))}</div>
        <div class="q-ans-w">${esc(q.why)}</div>
      </div>` : ''}
      <div class="q-foot"><span class="chip" data-tip="${q.src[0]}|${q.src[1]}">${esc(q.src[2])}</span></div>
    </div>`;
  }).join('') + '</div>';
}
function renderRightQ(){
  const q = selQ ? QZ.find(x => x.id === selQ) : null;
  $('#rightQ').classList.toggle('hide', !q);
  if (!q){
    $('#rwq').innerHTML = `<div class="rw-empty"><b>点左边任意一道题</b>
      选中后可以<b>重新生成</b>，或者告诉 AI 怎么改。<br><br>
      题目都带着参考答案与出处，员工答错能一键跳回原文看。</div>`;
    return;
  }
  $('#rwq').innerHTML = `
    <div class="rw-sel"><div class="rw-sel-t">第 ${QZ.findIndex(x => x.id === q.id) + 1} 题 · ${q.ty} · ${q.df}</div>
      <div class="rw-sel-n">${esc(q.st)}</div></div>
    <button class="rw-main" id="reQ">重新生成这道题</button>
    <div class="rw-lb">换个题型</div>
    <div class="tys">${QZ_TYPES.map(t =>
      `<button class="ty${q.ty === t ? ' on' : ''}" data-ty="${t}">${t}</button>`).join('')}</div>
    <div class="rw-lb">或告诉 AI 怎么改</div>
    <textarea class="rw-in" id="rwQIn" rows="3" placeholder="例：改成情景题 / 难度调到难 / 考 PID 参数"></textarea>
    <button class="rw-go" id="rwQGo">按指示生成</button>
    <div class="rw-lb">出处</div>
    <div class="note">${esc(DOCS.find(d => d.id === q.src[0]).n)}<br>
      <span class="chip" style="margin-top:6px;display:inline-block" data-tip="${q.src[0]}|${q.src[1]}">${esc(q.src[2])}</span></div>`;
}
$('#qzScroll').addEventListener('click', e => {
  const q = e.target.closest('[data-q]'); if (!q) return;
  selQ = q.dataset.q; renderQuiz(); renderRightQ();
});
$('#showAns').addEventListener('click', () => { showAns = !showAns; renderQuiz(); });
$('#reQz').addEventListener('click', () => {
  undoSnap = snapshot();
  ['q1','q2','q6'].forEach(id => {
    const a = QZ_ALT[id], q = QZ.find(x => x.id === id);
    if (a && q){
      q.st = a.st;
      if (a.blanks){ q.blanks = a.blanks; delete q.ops; delete q.ans; }
      else { q.ops = a.ops; q.ans = a.ans; delete q.blanks; }
      q.why = a.why;
    }
  });
  renderQuiz(); renderRightQ(); toast('已重新生成 3 道题');
});
$('#rwq').addEventListener('click', e => {
  const q = QZ.find(x => x.id === selQ); if (!q) return;
  if (e.target.id === 'reQ'){
    undoSnap = snapshot();
    const a = QZ_ALT[q.id];
    if (a){
      q.st = a.st;
      if (a.blanks){ q.blanks = a.blanks; delete q.ops; delete q.ans; }
      else { q.ops = a.ops; q.ans = a.ans; delete q.blanks; }
      q.why = a.why;
      toast('已重新生成这道题');
    } else { q.df = q.df === '易' ? '中' : q.df === '中' ? '难' : '易'; toast('已重新生成（难度调为「' + q.df + '」）'); }
    renderQuiz(); renderRightQ(); return;
  }
  const ty = e.target.closest('[data-ty]');
  if (ty){ changeQType(q, ty.dataset.ty); return; }
  if (e.target.id === 'rwQGo'){
    const v = (($('#rwQIn') || {}).value || '').trim();
    applyQInst(q, v || '换一种考法');
  }
});
/* 换题型：优先用预置版本，其次通用改写 */
function changeQType(q, ty){
  if (q.ty === ty) return;
  undoSnap = snapshot();
  if (ty === '填空题'){
    const f = QZ_FILL[q.id];
    if (f){ q.ty = '填空题'; q.st = f.st; q.blanks = f.blanks; q.why = f.why; delete q.ops; delete q.ans; toast('已改成填空题'); }
    else { applyQInst(q, '改成填空题'); return; }
  } else if (ty === '判断题'){
    if (q.ty === '填空题'){
      q.st = q.st.replace(/______/g, (m, i) => q.blanks[q.st.slice(0, i).match(/______/g) ? 0 : 0] || '');
      /* 逐空填入 */
      let k = 0; q.st = q.st.replace(/______/g, () => q.blanks[k++] || '');
      q.ty = '判断题'; q.ops = ['正确','错误']; q.ans = 0; delete q.blanks;
      toast('已改成判断题（按原文填空后作判断）');
    } else {
      q.ty = '判断题'; q.ops = ['正确','错误'];
      q.ans = Array.isArray(q.ans) ? 0 : (q.ans === 0 ? 0 : 1);
      toast('已改成判断题');
    }
  } else {
    const base = q.ty === '填空题' ? (q.blanks || [''])[0] : (Array.isArray(q.ans) ? q.ops[q.ans[0]] : q.ops[q.ans]);
    q.ty = ty === '步骤排序' ? '步骤排序' : '单选题';
    if (q.ty === '步骤排序'){
      q.ops = (q.ops && q.ops.length >= 3) ? q.ops : ['记录报警代码与工艺参数','检查热电偶','检查加热圈','检查冷却水路与 PID'];
      q.ans = q.ops.map((_, i) => i);
    } else {
      q.ops = [base, '以上都不对', '视当班情况而定', '由班长现场判断'];
      q.ans = 0;
    }
    delete q.blanks;
    toast('已改成' + ty);
  }
  renderQuiz(); renderRightQ();
}
/* 按指令改题 */
function applyQInst(q, inst){
  const t = inst || '';
  undoSnap = snapshot();
  if (/填空/.test(t) && q.ty !== '填空题'){ changeQType(q, '填空题'); return; }
  if (/情景|场景/.test(t)){
    q.ty = '单选题'; delete q.blanks;
    q.st = '【情景】夜班 2 点，3 号线报温度异常，你到现场后发现上一班刚换过加热圈。此时第一步该做什么？';
    q.ops = ['直接拆检新换的加热圈','先记录报警代码与当时的工艺参数','把 PID 参数复位','通知白班处理'];
    q.ans = 1;
    q.why = '换过配件不代表配件没问题，但第一步仍是记录 —— 没有参数记录，后面全是猜。';
    toast('已改成情景题');
  } else if (/难/.test(t)){
    q.df = '难'; toast('难度已调为「难」');
  } else if (/易|简单/.test(t)){
    q.df = '易'; toast('难度已调为「易」');
  } else {
    const a = QZ_ALT[q.id];
    if (a){
      q.st = a.st;
      if (a.blanks){ q.blanks = a.blanks; delete q.ops; delete q.ans; }
      else { q.ops = a.ops; q.ans = a.ans; delete q.blanks; }
      q.why = a.why;
      toast('已按指示重新生成');
    } else {
      q.st = q.st.replace(/[。？]?$/, '') + '（按指示调整后）';
      toast('已按指示重新生成');
    }
  }
  renderQuiz(); renderRightQ();
}

/* ============================================================
   课件视图 —— 只保留「按指示生成选中的页」
   ============================================================ */
function renderThemes(){
  $('#themes').innerHTML = THEMES.map(t => `
    <div class="th${TH === t.id ? ' on' : ''}" data-th="${t.id}">
      <div class="th-sw" style="background:${t.bg};border-left:9px solid ${t.ac}"></div>
      <div class="th-n">${t.n}</div>
    </div>`).join('');
}
function renderSlList(){
  $('#slCount').textContent = SLIDES.length + ' 页';
  const all = slMul.length === SLIDES.length;
  const sa = $('#slAll'); if (sa) sa.classList.toggle('on', all);
  const sn = $('#slAllN'); if (sn) sn.textContent = all ? '已全选' : `已选 ${slMul.length} 页`;
  $('#slList').innerHTML = SLIDES.map((s, i) => `
    <div class="sl-i${selSl === i ? ' on' : ''}" data-sli="${i}">
      <span class="ckm${slMul.indexOf(i) >= 0 ? ' on' : ''}" data-ck="${i}">✓</span>
      <span class="sl-i-n">${i + 1}</span><span>${esc(s.t)}</span>
    </div>`).join('');
}
function renderSlides(){
  const t = THEMES.find(x => x.id === TH);
  $('#ptMeta').textContent = `${SLIDES.length} 页 · 配色：${t.n} · 每页带演讲备注`;
  $('#ptScroll').innerHTML = '<div class="grid">' + SLIDES.map((s, i) => {
    if (busySl.indexOf(i) >= 0) return `
      <div class="sl on" data-sl="${i}" style="background:${t.bg};border-color:${t.soft}">
        <div class="sl-in" style="justify-content:center">
          <div class="sk" style="width:56%"></div><div class="sk" style="width:80%"></div>
          <div class="sk" style="width:70%"></div><div class="sk" style="width:44%"></div>
        </div>
        <span class="sl-pg" style="color:${t.fg}">${i + 1}</span>
      </div>`;
    return `
    <div class="sl${s.cover ? ' cover' : ''}${selSl === i ? ' on' : ''}${slMul.indexOf(i) >= 0 ? ' mul' : ''}" data-sl="${i}"
         style="background:${t.bg};border-color:${t.soft}">
      <div class="sl-in">
        ${s.cover
          ? `<div class="sl-t" style="color:${t.ac}">${esc(s.t)}</div>
             <div class="sl-s" style="color:${t.fg}">${esc(s.s)}</div>
             <div class="sl-li" style="color:${t.fg};padding-left:0">${esc(s.pts[0] || '')}</div>`
          : `<div class="sl-t" style="color:${t.ac}">${esc(s.t)}</div>
             <ul class="sl-ul">${s.pts.map(p => `<li class="sl-li" style="color:${t.fg}">${esc(p)}</li>`).join('')}</ul>`}
      </div>
      <span class="sl-pg" style="color:${t.fg}">${i + 1}</span>
      <span class="sl-ck${slMul.indexOf(i) >= 0 ? ' on' : ''}" data-ck="${i}">✓</span>
    </div>`;
  }).join('') + '</div>';
}
function renderRightP(){
  const n = slMul.length;
  const label = n > 1
    ? `已选 ${n} 页：第 ${slMul.slice().sort((a,b)=>a-b).map(i => i + 1).join('、')} 页`
    : `第 ${selSl + 1} 页 · ${esc(SLIDES[selSl].t)}`;
  $('#rwp').innerHTML = `
    <div class="rw-sel"><div class="rw-sel-t">${n > 1 ? '按指示批量生成' : '按指示生成这一页'}</div>
      <div class="rw-sel-n">${label}</div></div>
    <textarea class="rw-in" id="rwPIn" rows="3" placeholder="例：只讲热电偶，加一个现场案例，字数压到 5 条以内"></textarea>
    <button class="rw-go" id="rwPGo">按指示生成${n > 1 ? '（' + n + ' 页）' : ''}</button>
    <div class="rw-tip">想一次改多页？在左边页面列表或下方缩略图上<b>勾选</b>再下指令。</div>
    <div class="rw-lb">演讲备注</div>
    <div class="note">${esc(SLIDES[selSl].note || '（这一页还没有备注）')}</div>
    <div class="rw-lb">出处</div>
    <div class="note">${SLIDES[selSl].src ? `<span class="chip" data-tip="${SLIDES[selSl].src[0]}|${SLIDES[selSl].src[1]}">${esc(SLIDES[selSl].src[2])}</span>`
      : '这一页没有引用原文（封面 / 目录 / 小结属正常）'}</div>`;
}
$('#ptScroll').addEventListener('click', e => {
  const ck = e.target.closest('[data-ck]');
  if (ck){ toggleMul(+ck.dataset.ck); return; }
  const s = e.target.closest('[data-sl]'); if (!s) return;
  const i = +s.dataset.sl;
  selSl = i; slMul = [i];
  renderSlList(); renderSlides(); renderRightP();
});
$('#slList').addEventListener('click', e => {
  const ck = e.target.closest('[data-ck]');
  if (ck){ toggleMul(+ck.dataset.ck); return; }
  const s = e.target.closest('[data-sli]'); if (!s) return;
  selSl = +s.dataset.sli; slMul = [selSl];
  renderSlList(); renderSlides(); renderRightP();
  const el = document.querySelector(`[data-sl="${selSl}"]`);
  if (el) el.scrollIntoView({ behavior:'smooth', block:'center' });
});
function toggleMul(i){
  const k = slMul.indexOf(i);
  if (k >= 0){ if (slMul.length > 1) slMul.splice(k, 1); else return; }
  else slMul.push(i);
  slMul.sort((a, b) => a - b);
  selSl = slMul[slMul.length - 1];
  renderSlList(); renderSlides(); renderRightP();
}
/* 全选 / 反选 */
$('#slAll').addEventListener('click', () => {
  slMul = slMul.length === SLIDES.length ? [selSl] : SLIDES.map((_, i) => i);
  renderSlList(); renderSlides(); renderRightP();
  toast(slMul.length === SLIDES.length ? `已全选 ${SLIDES.length} 页` : '已取消全选');
});
$('#slInv').addEventListener('click', () => {
  const inv = SLIDES.map((_, i) => i).filter(i => slMul.indexOf(i) < 0);
  slMul = inv.length ? inv : [selSl];
  selSl = slMul[slMul.length - 1];
  renderSlList(); renderSlides(); renderRightP();
  toast(`已反选，当前 ${slMul.length} 页`);
});
$('#themes').addEventListener('click', e => {
  const b = e.target.closest('[data-th]'); if (!b) return;
  TH = b.dataset.th; renderThemes(); renderSlides();
  toast('已换配色：' + THEMES.find(x => x.id === TH).n);
});
$('#rwp').addEventListener('click', e => {
  if (e.target.id !== 'rwPGo') return;
  const v = (($('#rwPIn') || {}).value || '').trim();
  runSlides(v || '换个写法');
});
/* 按指令生成选中的页：命中关键词给真反馈 */
function applySlInst(s, inst){
  const t = inst || '';
  if (/压|短|少|精简|5\s*条|五条/.test(t)){
    s.pts = s.pts.slice(0, 4);
    return '已压缩';
  }
  if (/案例|例子|现场/.test(t)){
    s.pts = s.pts.concat(['案例：3 号线 8 月热电偶插头氧化致温度跳变']);
    return '已加案例';
  }
  if (/图|示意|流程/.test(t)){
    s.t = s.t + '（图示版）';
    s.pts = ['见流程图：' + (s.pts[0] || ''), '讲的时候照着图说，不必念字'];
    return '已改成图示';
  }
  if (/表|对比/.test(t)){
    s.t = s.t + '（对比表）';
    s.pts = ['项目 / 正常 / 异常', s.pts.slice(0, 2).map(p => p.split('：')[0] + ' / — / —').join('　')];
    return '已改成对比表';
  }
  const a = SL_ALT[SLIDES.indexOf(s)];
  if (a){ s.t = a.t; s.pts = a.pts; return '已换个写法'; }
  s.pts = s.pts.map(p => p.replace(/（.*）$/, '')) .concat(['（已按指示调整）']);
  return '已按指示调整';
}
function runSlides(inst){
  undoSnap = snapshot();
  const idx = slMul.slice();
  busySl = idx; renderSlides();
  $('#ptTag').hidden = false;
  $('#ptTag').textContent = 'AI 正在改 ' + idx.length + ' 页…';
  setTimeout(() => {
    const msgs = [];
    idx.forEach(i => { if (SLIDES[i]) msgs.push(applySlInst(SLIDES[i], inst)); });
    busySl = [];
    $('#ptTag').hidden = true;
    renderSlList(); renderSlides(); renderRightP();
    toast((msgs[0] || '已更新') + '：' + idx.map(i => '第 ' + (i + 1) + ' 页').join('、'));
  }, 1000);
}

/* ============================================================
   撤销
   ============================================================ */
function snapshot(){ return JSON.stringify({ KPS, QZ, SLIDES, TH }); }
function restore(s){ const o = JSON.parse(s); KPS = o.KPS; QZ = o.QZ; SLIDES = o.SLIDES; TH = o.TH; }
function toast(t){
  $('#toastT').textContent = t;
  $('#toast').hidden = false;
  clearTimeout(window.__tt);
  window.__tt = setTimeout(() => { $('#toast').hidden = true; }, 4600);
}
$('#undoBtn').addEventListener('click', () => {
  if (!undoSnap) return;
  restore(undoSnap); undoSnap = null;
  $('#toast').hidden = true;
  if (!KPS.find(x => x.id === selKp)) selKp = null;
  if (!QZ.find(x => x.id === selQ)) selQ = null;
  slMul = slMul.filter(i => i < SLIDES.length);
  if (!slMul.length) slMul = [0];
  selSl = Math.min(selSl, SLIDES.length - 1);
  renderResult();
  toast('已撤销');
  setTimeout(() => { $('#toast').hidden = true; }, 1600);
});

/* ---------- 其它目录操作 ---------- */
$('#addSec').addEventListener('click', () => {
  undoSnap = snapshot();
  const id = 'k' + Date.now();
  KPS.push({ id, t:'新的一节（双击改名）', dom:'待归类', def:'（空）双击这里写要点，或让 AI 按指示生成。', pts:['待补充'], srcs:[] });
  selKp = id;
  renderOutline(); renderDoc(); renderRight();
  toast('已加一节 · 双击名字可以改');
});
$('#aiSuggest').addEventListener('click', () => {
  openModal('AI 建议补什么', SUGGEST.map((g, i) =>
    `<div class="hi"><span class="hi-c"><b>${esc(g.t)}</b>
      <div class="hi-d">${esc(g.why)}</div>
      <button class="mini" data-add="${i}" style="margin-top:7px">加入目录</button></span></div>`).join(''));
});
$('#mdB').addEventListener('click', e => {
  const a = e.target.closest('[data-add]'); if (!a) return;
  const g = SUGGEST[+a.dataset.add];
  undoSnap = snapshot();
  KPS.push({ id:'g' + Date.now(), t:g.t, dom:'AI 建议', def:g.def, pts:g.pts, srcs:g.srcs });
  closeModal(); renderOutline(); renderDoc(); renderRight();
  toast('已加入目录：' + g.t);
});

/* ============================================================
   底部操作
   ============================================================ */
/* ============================================================
   导出：先想「拿去干什么」，再选格式
   ============================================================ */
const USES = [
  { id:'use',  n:'直接用',   d:'打印 / 发群 / 上课讲' },
  { id:'fill', n:'员工填写', d:'能直接当答卷用' },
  { id:'sys',  n:'导入系统', d:'LMS / 考试系统 / 员工端' },
  { id:'arch', n:'存档备查', d:'合规检查要的那一份' }
];
const EXP = {
  kp: [
    { u:'use',  id:'docx', fn:'学习手册',     ext:'docx', rec:1, n:'Word 学习手册',       d:'还能再改，也能直接打印' },
    { u:'use',  id:'pdf',  fn:'学习手册',     ext:'pdf',  rec:1, n:'PDF 学习手册',        d:'发群里或打印，格式不会乱' },
    { u:'use',  id:'a3',   fn:'岗位一页纸',   ext:'pdf',         n:'A3 岗位一页纸',       d:'只印要点，贴设备旁或班前会用' },
    { u:'fill', id:'chk',  fn:'岗位自查表',   ext:'pdf',  rec:1, n:'岗位自查表',          d:'每条后面留 □，员工自查打勾、签字' },
    { u:'fill', id:'note', fn:'课堂笔记版',   ext:'pdf',         n:'课堂笔记版',          d:'要点留空、右侧留笔记栏，边听边记' },
    { u:'sys',  id:'xlsx', fn:'知识点清单',   ext:'xlsx', rec:1, n:'Excel 知识点清单',    d:'一行一个知识点，培训部自己维护' },
    { u:'sys',  id:'json', fn:'结构化数据',   ext:'json', rec:1, n:'JSON 结构化数据',     d:'员工端知识地图直接导入' },
    { u:'sys',  id:'csv',  fn:'知识点清单',   ext:'csv',         n:'CSV 通用表格',        d:'哪都能开，字段最简' },
    { u:'arch', id:'arc',  fn:'存档版',       ext:'pdf',  rec:1, n:'存档版 PDF',          d:'末尾附：依据资料及版本、发布人、发布时间' },
    { u:'arch', id:'zip',  fn:'全部格式',     ext:'zip',         n:'全部格式打包',        d:'上面所有格式打成一个压缩包' }
  ],
  qz: [
    { u:'use',  id:'tea',   fn:'教师版试卷',                ext:'pdf',  rec:1, n:'教师版试卷',        d:'答案与解析都在题下面，讲课、讲评用' },
    { u:'use',  id:'teaw',  fn:'教师版试卷',                ext:'docx',        n:'教师版试卷 Word',   d:'题目还能再改' },
    { u:'fill', id:'stu',   fn:'学生版试卷（可直接作答）',  ext:'pdf',  rec:1, n:'学生版试卷',        d:'无答案；有姓名/工号/分数栏，判断打勾、填空画横线、排序留序号' },
    { u:'fill', id:'card',  fn:'答题卡',                    ext:'pdf',         n:'答题卡（可涂点）',  d:'A4 半页，姓名工号 + A/B/C/D 涂点，收上来好批' },
    { u:'fill', id:'qr',    fn:'在线答题二维码',            ext:'pdf',         n:'在线答题二维码',    d:'一页纸一个码，扫码在手机上答，自动判分、成绩直接进档案' },
    { u:'sys',  id:'xlsx',  fn:'题库',                      ext:'xlsx', rec:1, n:'Excel 题库',        d:'一行一道题，培训部维护用' },
    { u:'sys',  id:'qti',   fn:'QTI2.1',                    ext:'zip',         n:'QTI 2.1 标准包',    d:'Moodle / Blackboard / 考试系统通用导入格式' },
    { u:'sys',  id:'aiken', fn:'Aiken',                     ext:'txt',         n:'Aiken 纯文本',      d:'最简文本，Moodle 快速导入' },
    { u:'sys',  id:'json',  fn:'题目数据',                  ext:'json', rec:1, n:'JSON 结构化数据',   d:'员工端练习与考试直接导入' },
    { u:'arch', id:'arc',   fn:'存档版（含答案与出题依据）', ext:'pdf',  rec:1, n:'存档版 PDF',        d:'每题附原文出处、发布人、依据资料版本' },
    { u:'arch', id:'zip',   fn:'全部格式',                  ext:'zip',         n:'全部格式打包',      d:'上面所有格式打成一个压缩包' }
  ],
  pt: [
    { u:'use',  id:'pptx',  fn:'培训课件',                  ext:'pptx', rec:1, n:'PPTX 可编辑',       d:'能再改，也能直接投影' },
    { u:'use',  id:'pdf',   fn:'培训课件',                  ext:'pdf',  rec:1, n:'PDF 投影版',        d:'16:9，投影或发群，格式不会乱' },
    { u:'use',  id:'hand',  fn:'讲义版（3页+笔记线）',      ext:'pdf',         n:'讲义版 PDF',        d:'一页 3 张、右侧留笔记线，学员人手一份' },
    { u:'use',  id:'img',   fn:'课件图片',                  ext:'zip',         n:'图片打包',          d:'每页一张 PNG，发微信群或放车间电视' },
    { u:'fill', id:'sign',  fn:'培训记录表（含签到栏）',    ext:'pdf',  rec:1, n:'培训记录表',        d:'课程要点 + 签到栏，培训完签字留档，合规检查要查' },
    { u:'sys',  id:'scorm', fn:'SCORM',                     ext:'zip',         n:'SCORM 课件包',      d:'传到 LMS 能记学时、记完成率' },
    { u:'sys',  id:'note',  fn:'讲师讲稿',                  ext:'docx',        n:'演讲备注 Word',     d:'逐页讲稿，打印出来拿着讲' },
    { u:'arch', id:'arc',   fn:'存档版（附资料依据）',      ext:'pdf',  rec:1, n:'存档版 PDF',        d:'末尾附：依据资料及版本、发布人、发布时间' },
    { u:'arch', id:'zip',   fn:'全部格式',                  ext:'zip',         n:'全部格式打包',      d:'上面所有格式打成一个压缩包' }
  ]
};
const BASE = { kp:'知识点清单', qz:'随堂测验', pt:'培训课件' };
let expU = 'use', expF = null, expSrc = true, expPart = false, expMix = false, expMixOp = false;
function expList(){ return (EXP[kind] || []).filter(x => x.u === expU); }
function expCur(){ const l = expList(); return l.find(x => x.id === expF) || l.find(x => x.rec) || l[0] || null; }
function expCount(){ return kind === 'pt' ? slMul.length : (kind === 'qz' ? (selQ ? 1 : 0) : (selKp ? 1 : 0)); }
function expFile(x){ return x ? `${BASE[kind]} - ${x.fn}.${x.ext}` : '—'; }
function renderExp(){
  const l = expList(), cur = expCur(), n = expCount();
  const unit = kind === 'kp' ? '节' : kind === 'qz' ? '道' : '页';
  const selN = kind === 'pt' ? slMul.length : n;
  openModal('导出 —— 先想好拿去干什么用', `
    <div class="exp">
      <div class="exp-tabs">${USES.map(u =>
        `<button class="exp-tab${expU === u.id ? ' on' : ''}" data-eu="${u.id}"><b>${u.n}</b><span>${u.d}</span></button>`).join('')}</div>
      <div class="exp-list">${l.map(x => `
        <div class="exp-i${cur && cur.id === x.id ? ' on' : ''}" data-ef="${x.id}">
          <span class="exp-r"></span>
          <span class="exp-c">
            <span class="exp-n">${x.n}<span class="exp-e">.${x.ext}</span>${x.rec ? '<span class="exp-rec">常用</span>' : ''}</span>
            <span class="exp-d">${x.d}</span>
          </span>
        </div>`).join('')}</div>
      <div class="exp-opt">
        <div class="exp-lb">导出选项</div>
        <div class="exp-ck${expSrc ? ' on' : ''}" data-eo="src"><span class="ckm${expSrc ? ' on' : ''}">✓</span>附「资料依据与版本」页（合规检查用）</div>
        ${selN && selN < (kind === 'pt' ? SLIDES.length : kind === 'qz' ? QZ.length : KPS.length)
          ? `<div class="exp-ck${expPart ? ' on' : ''}" data-eo="part"><span class="ckm${expPart ? ' on' : ''}">✓</span>只导出选中的 ${selN} ${unit}</div>` : ''}
        ${kind === 'qz' ? `
          <div class="exp-ck${expMix ? ' on' : ''}" data-eo="mix"><span class="ckm${expMix ? ' on' : ''}">✓</span>打乱题序（防抄）</div>
          <div class="exp-ck${expMixOp ? ' on' : ''}" data-eo="mixop"><span class="ckm${expMixOp ? ' on' : ''}">✓</span>打乱选项顺序</div>` : ''}
      </div>
      <div class="exp-foot">
        <div class="exp-fn">将导出 <b>${expFile(cur)}</b></div>
        <button class="btn primary" id="doExp">确认导出</button>
      </div>
    </div>`, true);
}
$('#expBtn').addEventListener('click', () => {
  if (!expList().some(x => x.id === expF)) expF = null;
  renderExp();
});
$('#mdB').addEventListener('click', e => {
  const eu = e.target.closest('[data-eu]');
  if (eu){ expU = eu.dataset.eu; expF = null; renderExp(); return; }
  const ef = e.target.closest('[data-ef]');
  if (ef){ expF = ef.dataset.ef; renderExp(); return; }
  const eo = e.target.closest('[data-eo]');
  if (eo){
    const k = eo.dataset.eo;
    if (k === 'src') expSrc = !expSrc;
    if (k === 'part') expPart = !expPart;
    if (k === 'mix') expMix = !expMix;
    if (k === 'mixop') expMixOp = !expMixOp;
    renderExp(); return;
  }
  if (e.target.id === 'doExp'){
    closeModal();
    const ex = [];
    if (expSrc) ex.push('附资料依据页');
    if (expPart) ex.push('仅选中部分');
    if (expMix) ex.push('题序已打乱');
    if (expMixOp) ex.push('选项已打乱');
    toast('已导出：' + expFile(expCur()) + (ex.length ? '（' + ex.join(' · ') + '）' : ''));
  }
});
$('#pubBtn').addEventListener('click', () => {
  const n = kind === 'kp' ? KPS.length : kind === 'qz' ? QZ.length : SLIDES.length;
  const u = kind === 'kp' ? '个知识点' : kind === 'qz' ? '道题' : '页课件';
  openModal('发布到员工端', `<div class="md-b" style="padding:0">
    将发布 <b>${n} ${u}</b>。<br><br>
    发布后员工在 AI 导师里问到相关内容，会直接引用这里的原文出处。<br><br>
    <div class="note">发布内容会记录：发布时间、发布人、依据的资料版本。这条记录用于培训合规检查，你不用额外做什么。</div>
    <button class="btn primary" id="doPub" style="margin-top:12px">确认发布</button></div>`);
});
$('#mdB').addEventListener('click', e => {
  if (e.target.id === 'doPub'){
    closeModal();
    toast('已发布 · 员工端立即可见');
  }
});
$('#swKind').addEventListener('click', () => go(1));
$('#restart').addEventListener('click', () => { kind = null; selKp = null; selQ = null; go(1); });
document.addEventListener('click', e => {
  const g = e.target.closest('[data-go]');
  if (g) go(+g.dataset.go);
});

/* ============================================================
   浮层 / 提示
   ============================================================ */
function openModal(t, b, wide){
  $('#mdT').textContent = t; $('#mdB').innerHTML = b;
  const box = $('#modal .md-box'); if (box) box.classList.toggle('wide', !!wide);
  $('#modal').hidden = false;
}
function closeModal(){ $('#modal').hidden = true; }
$('#mdX').addEventListener('click', closeModal);
$('#modal').addEventListener('click', e => { if (e.target.id === 'modal') closeModal(); });

const tip = $('#tip');
document.addEventListener('mouseover', e => {
  const c = e.target.closest('[data-tip]'); if (!c) return;
  const [d, a] = c.dataset.tip.split('|');
  const doc = DOCS.find(o => o.id === d); if (!doc) return;
  const b = doc.blocks.find(x => x.a === a); if (!b) return;
  tip.innerHTML = `<b>${esc(doc.n)} · ${b.a}</b>${esc(b.t)}`;
  const r = c.getBoundingClientRect();
  tip.hidden = false;
  tip.style.left = Math.min(r.left, window.innerWidth - 356) + 'px';
  tip.style.top = (r.bottom + 8) + 'px';
});
document.addEventListener('mouseout', e => { if (e.target.closest('[data-tip]')) tip.hidden = true; });

/* ============================================================
   init
   ============================================================ */
renderSteps(); renderKinds(); renderDocs();

/* 供自动化测试调用 */
window.__app = {
  go, runGen, runKp, runSlides, changeQType, applyQInst,
  get step(){ return step; }, get kind(){ return kind; }, set kind(v){ kind = v; },
  get showAns(){ return showAns; }, get slMul(){ return slMul; },
  get expU(){ return expU; }, get expF(){ return expF; }, expFile: () => expFile(expCur()), expList,
  KPS: () => KPS, QZ: () => QZ, SLIDES: () => SLIDES,
  sel: v => { selKp = v; }, selQ: v => { selQ = v; }, selSl: v => { selSl = v; slMul = [v]; }
};
