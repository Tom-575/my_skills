/* ============================================================
   AI 学习导师 · 制造学院企业培训助手（界面原型 · 数据为模拟）
   目录：index.html / styles.css / app.js
   ============================================================ */

/* ============================================================
   1. 企业知识库文件（培训课程 / 文档 / 视频 / SOP / 规范）
   ============================================================ */
const FILES = {
  d1: {
    name: 'AI 学习导师使用指南 v2.3.pdf',
    kind: 'PDF', cls: 't-pdf',
    desc: '培训课程部 · 24 页 · 3.1 MB · 2026-08-28',
    meta: 'PDF · 3.1 MB · 共 24 页 · 培训课程部发布 · 2026-08-28',
    tags: ['入职必读', '工具使用', '全员'],
    blocks: [
      { t: 'h', text: '二、AI 学习导师能帮你做什么' },
      { t: 'p', id: 'p1', anchor: true, text: 'AI 导师的定位是「岗位学习的导航员」，而不是万能问答机。它只依据企业知识库已有内容作答，并在每一条结论后标注出处，方便你回到原文核对。核心能力有三类：（1）答疑——回答岗位操作、工艺、规范类问题；（2）规划——基于岗位能力模型生成个人学习路径；（3）陪练——围绕 SOP 与考试题库进行情景提问与纠错。' },
      { t: 'p', id: 'p2', text: '使用前提：提问时说明你的岗位、当前水平和目标。信息越具体，检索到的资料越贴合。示例：不说「怎么修机器」，而说「我是注塑岗初级工，想学料筒温度异常的排查步骤」。' },
      { t: 'h', text: '三、三种推荐提问方式' },
      { t: 'p', id: 'p3', text: '① 学什么：「我想达到 XX 岗位要求，需要学哪些内容，按什么顺序？」② 怎么学：「这个概念太抽象，能结合车间实际讲讲吗？」③ 学得怎么样：「出 3 道题考考我，并对我的答案点评。」' },
      { t: 'quote', text: '注意：AI 导师给出的操作步骤必须以现行 SOP / 规范原文为准。若回答与纸质作业指导书不一致，以作业指导书为准并向培训部反馈。' }
    ]
  },

  d2: {
    name: '转岗员工 30 天成长路径图（设备维护岗）.docx',
    kind: 'DOC', cls: 't-doc',
    desc: '人力资源部 · 9 页 · 640 KB · 2026-09-01',
    meta: 'DOCX · 640 KB · 共 9 页 · 人力资源部 · 2026-09-01',
    tags: ['转岗', '学习路径', '设备维护岗'],
    blocks: [
      { t: 'h', text: '一、30 天路径总览' },
      { t: 'p', id: 'p1', anchor: true, text: '路径分四个阶段：第 1 周「认知」——熟悉车间设备台账、安全红线与常用工器具；第 2 周「跟岗」——随师傅参与日常点检与保养，完成 10 次跟岗记录；第 3 周「实操」——在监护下独立完成一级保养作业；第 4 周「认证」——通过理论考试与实操考核，取得岗位上岗资格。' },
      { t: 'p', id: 'p2', text: '每周五下午为固定复盘时间，由带教师傅填写《周度成长评估表》，评估结果与转正定级挂钩。' },
      { t: 'h', text: '二、第一周任务清单与达标标准' },
      { t: 'p', id: 'p3', anchor: true, text: '第一周共 5 项任务：① 背诵本岗位 8 条安全红线并签字确认；② 认识车间 6 类主要设备并说出其用途；③ 完成《设备维护岗入门》线上课程（2 学时）且测试 ≥ 80 分；④ 跟随师傅完成 3 次班前点检；⑤ 在 AI 导师完成 1 次学习路径咨询并生成个人计划。达标标准：五项任务全部留痕，缺一项不予进入第二周。' },
      { t: 'p', id: 'p4', text: '第一周不安排独立操作任何设备，包括更换模具、进入设备内部清洁等，须在有资质人员监护下进行。' },
      { t: 'quote', text: '带教师傅职责：每日至少 30 分钟现场答疑，并对学员提出的问题做记录，作为课程优化的 inputs。' }
    ]
  },

  d3: {
    name: 'SOP-ME-017 注塑机常见故障排查作业指导书',
    kind: 'SOP', cls: 't-sop',
    desc: '设备管理部 · 现行版本 · 命中 4.2 节 · 2026-06-18',
    meta: 'SOP · 现行版本 V3.2 · 共 18 页 · 设备管理部 · 2026-06-18',
    tags: ['注塑机', '故障排查', '必修'],
    blocks: [
      { t: 'h', text: '4.2 料筒温度异常（报警 E-12 / E-13）' },
      { t: 'p', id: 'p1', text: '适用范围：所有型号注塑机的料筒加热段温度异常报警。作业前必须停机、挂牌上锁（LOTO），并由具备操作资质的人员执行。' },
      { t: 'p', id: 'p2', anchor: true, text: '排查四步法：第一步，记录报警代码与发生时的工艺参数（设定温度、实际温度、生产周期）；第二步，检查热电偶接线与插入深度，用万用表测量阻值判断是否损坏；第三步，检查加热圈是否断路或接地，测量各段电流是否正常；第四步，检查冷却水路与温控表参数，确认是否为水路堵塞或 PID 参数漂移。' },
      { t: 'p', id: 'p3', anchor: true, text: '常见根因排序（按历史工单统计）：热电偶松动或老化 42%、加热圈损坏 28%、冷却水路结垢 15%、温控表 PID 参数漂移 10%、其他 5%。因此优先检查热电偶，可覆盖近半数场景。' },
      { t: 'p', id: 'p4', text: '处理完成后须填写《设备异常处理单》，注明报警代码、根因、更换配件编号与处理结果，并在 MES 系统中闭环工单。未闭环的工单不得跨班次移交。' },
      { t: 'quote', id: 'q1', text: '⚠ 安全提示：严禁在带电状态下拆卸加热圈接线端子；料筒高温区作业必须佩戴隔热手套与护目镜。' },
      { t: 'note', text: '—— SOP-ME-017 V3.2 · 编制：设备管理部 · 审核：王建国 · 批准日期 2026-06-18' }
    ]
  },

  d4: {
    name: '注塑成型工艺与设备维护 · 第 4 章（培训课件）.pptx',
    kind: 'PPT', cls: 't-ppt',
    desc: '制造学院 · 36 页 · 12.8 MB · 2026-09-02',
    meta: 'PPTX · 12.8 MB · 共 36 页 · 制造学院 · 2026-09-02',
    tags: ['培训课程', '注塑工艺', '中级'],
    blocks: [
      { t: 'h', text: '第 18 页 · 温度控制系统的组成' },
      { t: 'p', id: 'p1', text: '料筒温控系统由四部分组成：热电偶（感知）、加热圈（执行）、温控表 / PLC（决策）、冷却水路（散热）。任一环节失效都会表现为温度异常。' },
      { t: 'p', id: 'p2', anchor: true, text: '理解这个闭环后，故障排查就有了顺序：先确认感知是否准确（热电偶），再确认执行是否到位（加热圈），最后看决策参数（PID）与散热条件（水路）。这也是 SOP-ME-017 中四步法的编排逻辑。' },
      { t: 'p', id: 'p3', text: 'PID 参数整定要点：比例带过大导致响应慢，过小导致温度振荡；积分时间过短易超调。现场一般使用厂家默认值，仅在更换加热圈规格后需要重新整定。' },
      { t: 'quote', text: '本节配套练习：给定 3 组温度曲线，判断各属于哪种失效模式。' }
    ]
  },

  d5: {
    name: '设备点检与日常保养规范 QG/SC-208',
    kind: 'PDF', cls: 't-pdf',
    desc: '制造部 · 22 页 · 命中第 7 页 · 2026-07-11',
    meta: 'PDF · 2.6 MB · 共 22 页 · 制造部 · 2026-07-11',
    tags: ['点检', '保养', '规范'],
    blocks: [
      { t: 'h', text: '7. 点检记录填写要求' },
      { t: 'p', id: 'p1', anchor: true, text: '点检记录须做到「三不」：不空项、不代签、不事后补填。每一项均需填写实测值或明确的状态判断（正常 / 异常），不得使用「/」「同上」等模糊表述。异常项必须在备注中写明现象与临时处置措施。' },
      { t: 'p', id: 'p2', text: '点检分为班前点检（10 分钟内）、周点检（30 分钟）与月度专业点检（由设备员执行）。班前点检 8 项必查：油位、气压、急停按钮、安全光栅、润滑、异响、泄漏、紧固。' },
      { t: 'p', id: 'p3', anchor: true, text: '异常处理闭环：点检发现异常 → 现场挂牌 → 填报《设备异常处理单》→ 维修处理 → 维修人签字 → 点检人复检确认 → 归档。任一步骤缺失视为未闭环，月度设备完好率考核中扣分。' },
      { t: 'quote', text: '记录保存期限：纸质点检表保存 1 年，MES 电子记录保存 3 年。' }
    ]
  },

  d6: {
    name: '车间汇报 PPT 制作规范与模板.pptx',
    kind: 'PPT', cls: 't-ppt',
    desc: '制造学院 · 28 页 · 8.4 MB · 2026-05-20',
    meta: 'PPTX · 8.4 MB · 共 28 页 · 制造学院 · 2026-05-20',
    tags: ['办公技能', '汇报规范', '通用'],
    blocks: [
      { t: 'h', text: '三、页面内容规范' },
      { t: 'p', id: 'p1', anchor: true, text: '一页只讲一个结论，标题即结论（如「3 号线 OEE 环比提升 4.2%」），而不是「生产情况汇报」。正文每页不超过 6 行，每行不超过 20 字。' },
      { t: 'p', id: 'p2', anchor: true, text: '数据优先用图表呈现：趋势用折线图、构成用堆叠柱、对比用柱状图、占比用饼图（不超过 5 个分类）。所有图表必须标注单位、数据来源与统计周期。' },
      { t: 'p', id: 'p3', text: '字号下限：标题 28 磅，正文 18 磅，图表标签 14 磅。母版统一使用企业蓝（#1D4ED8）+ 灰（#64748B）双色，禁止使用渐变背景、艺术字与三种以上强调色。' },
      { t: 'p', id: 'p4', text: '汇报结构推荐：现状 → 问题 → 原因分析 → 对策 → 需要的支持。五页讲清楚一件事，比二十页流水账更有效。' },
      { t: 'quote', text: '常见扣分点：整页文字截图、动画过多、数据未标口径、结论与数据不匹配。' }
    ]
  },

  d7: {
    name: '视频：注塑机结构原理与常见故障（第 3 讲 · 42 分钟）',
    kind: '视频', cls: 't-video',
    desc: '制造学院 · 课程编号 ME-203 · 2026-04-16',
    meta: 'MP4 · 42 分钟 · 课程编号 ME-203 · 制造学院 · 2026-04-16',
    tags: ['视频课程', '注塑机', '第 3 讲'],
    blocks: [
      { t: 'video', title: '第 3 讲 · 温控系统与料筒结构', sub: '主讲：李工程师（设备管理部） · 时长 42:16', time: '12:30' },
      { t: 'h', text: '本讲知识点' },
      { t: 'p', id: 'p1', text: '00:00–08:20 料筒与螺杆的结构拆解；08:20–20:40 加热圈与热电偶的工作原理与拆装演示；20:40–33:10 温度异常的三类典型失效模式实拍；33:10–42:16 现场实操：热电偶更换与阻值测量。' },
      { t: 'p', id: 'p2', anchor: true, text: '重点观看 20:40–33:10 段，讲师用三台实机演示了热电偶松动、加热圈断路、水路结垢三种失效对应的温度曲线形态，与 SOP-ME-017 的排查顺序完全对应。' },
      { t: 'p', id: 'p3', text: '课后作业：观看后完成 5 道随堂测验（≥ 80 分通过），并在 MES 学习中心上传一份不少于 200 字的学习笔记。' }
    ]
  },

  d8: {
    name: '受限空间作业安全管理规范 AQ-3028',
    kind: '规范', cls: 't-gf',
    desc: '安全环保部 · 强制标准 · 2026-03-05',
    meta: '规范 · 强制标准 · 共 16 页 · 安全环保部 · 2026-03-05',
    tags: ['安全', '强制', '受限空间'],
    blocks: [
      { t: 'h', text: '4. 作业前准备' },
      { t: 'p', id: 'p1', anchor: true, text: '受限空间作业实行「先通风、再检测、后作业」。氧气浓度须在 19.5%–23.5% 之间，可燃气体浓度低于爆炸下限的 10%，有毒有害气体浓度符合职业接触限值。检测结果须记录并经作业负责人签字。' },
      { t: 'p', id: 'p2', text: '必须配备监护人员，监护人不得进入受限空间，且不得兼任其他工作。作业期间每 30 分钟复测一次气体浓度，作业中断超过 30 分钟须重新检测。' },
      { t: 'quote', text: '严禁事项：未办理《受限空间作业许可证》作业；使用纯氧通风；使用非防爆工具与照明。' }
    ]
  }
};

/* ============================================================
   2. 会话样例
   ============================================================ */
const CONVS = [
  {
    id: 'c1', title: '如何使用 AI 导师学习', group: '今天', sub: '5 条消息 · 09:12', active: true,
    rec: ['d1', 'd2', 'd7'],
    messages: [
      { role: 'user', text: '我刚从装配岗调到设备维护岗，完全不知道从哪开始学。这个 AI 导师到底该怎么用？' },
      {
        role: 'ai',
        html: `<p>先说定位：AI 导师是<strong>岗位学习的导航员</strong>，不是万能问答机。它只依据企业知识库作答，每条结论都会标注出处，你可以随时回到原文核对<sup class="cite" data-file="d1" data-anchor="p1">1</sup>。</p>
        <p>它主要帮你解决三件事：</p>
        <ul>
          <li><strong>学什么</strong> —— 基于岗位能力模型，排出学习顺序，避免东一榔头西一棒；</li>
          <li><strong>怎么学</strong> —— 把抽象概念翻译成车间里的真实场景；</li>
          <li><strong>学得怎么样</strong> —— 出题考你、点评你的答案<sup class="cite" data-file="d1" data-anchor="p3">2</sup>。</li>
        </ul>
        <div class="path-card">
          <h4>
            <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12h4l3 8 4-16 3 8h4"/></svg>
            你的转岗学习路径 · 30 天
          </h4>
          <div class="step"><div class="step-n">1</div><div class="step-b"><div class="step-t">第 1 周 · 认知</div><div class="step-d">安全红线、设备台账、常用工器具；完成入门线上课程</div></div></div>
          <div class="step"><div class="step-n">2</div><div class="step-b"><div class="step-t">第 2 周 · 跟岗</div><div class="step-d">随师傅参与日常点检，完成 10 次跟岗记录</div></div></div>
          <div class="step"><div class="step-n">3</div><div class="step-b"><div class="step-t">第 3 周 · 实操</div><div class="step-d">在监护下独立完成一级保养作业</div></div></div>
          <div class="step"><div class="step-n">4</div><div class="step-b"><div class="step-t">第 4 周 · 认证</div><div class="step-d">理论 + 实操考核，取得上岗资格</div></div></div>
        </div>
        <p style="margin-top:12px">以上来自《转岗员工 30 天成长路径图》，每周五下午由带教师傅复盘评估<sup class="cite" data-file="d2" data-anchor="p1">3</sup><sup class="cite" data-file="d2" data-anchor="p2">4</sup>。</p>
        <p>顺便提醒一句：以后提问时带上<strong>你的岗位、当前水平和目标</strong>，比如「我是注塑岗初级工，想学料筒温度异常的排查步骤」，检索结果会准很多<sup class="cite" data-file="d1" data-anchor="p2">5</sup>。</p>`,
        cites: [
          { file: 'd1', anchor: 'p1', score: 0.95, quote: 'AI 导师的定位是「岗位学习的导航员」，而不是万能问答机…核心能力有三类' },
          { file: 'd1', anchor: 'p3', score: 0.88, quote: '① 学什么 ② 怎么学 ③ 学得怎么样' },
          { file: 'd2', anchor: 'p1', score: 0.93, quote: '路径分四个阶段：第 1 周「认知」…第 4 周「认证」' },
          { file: 'd2', anchor: 'p2', score: 0.81, quote: '每周五下午为固定复盘时间…评估结果与转正定级挂钩' },
          { file: 'd1', anchor: 'p2', score: 0.76, quote: '提问时说明你的岗位、当前水平和目标' }
        ]
      },
      { role: 'user', text: '那第一周具体要做什么？怎么才算学会了？' },
      {
        role: 'ai',
        html: `<p>第一周是<strong>认知周，不安排任何独立操作</strong>（包括换模、进设备内部清洁），所有动作都要在有资质的人监护下进行<sup class="cite" data-file="d2" data-anchor="p4">3</sup>。</p>
        <p>五件事，做完且留痕即算达标：</p>
        <ol>
          <li>背下本岗位 <strong>8 条安全红线</strong>并签字确认；</li>
          <li>认识车间 <strong>6 类主要设备</strong>并说出用途；</li>
          <li>完成《设备维护岗入门》线上课程（2 学时），测试 <strong>≥ 80 分</strong>；</li>
          <li>跟随师傅完成 <strong>3 次班前点检</strong>；</li>
          <li>在 AI 导师完成 1 次学习路径咨询，生成个人计划 ✓（现在正在进行）</li>
        </ol>
        <p>达标标准很硬：<strong>五项全部留痕，缺一项不予进入第二周</strong><sup class="cite" data-file="d2" data-anchor="p3">1</sup>。</p>
        <p>给你配两样东西配合第 3 项和第 4 项 👇</p>
        <ul>
          <li>课程《注塑机结构原理与常见故障》<strong>第 3 讲</strong>，重点看 <strong>20:40–33:10</strong> 那段，讲师用三台实机演示了三种失效对应的温度曲线<sup class="cite" data-file="d7" data-anchor="p2">2</sup>；</li>
          <li>《设备点检与日常保养规范》里班前点检 <strong>8 项必查</strong>：油位、气压、急停按钮、安全光栅、润滑、异响、泄漏、紧固<sup class="cite" data-file="d5" data-anchor="p2">4</sup>。</li>
        </ul>
        <p>要不要我现在按第一周清单，给你出 5 道题检验一下？答完我逐题点评。</p>`,
        cites: [
          { file: 'd2', anchor: 'p3', score: 0.96, quote: '第一周共 5 项任务…达标标准：五项任务全部留痕' },
          { file: 'd7', anchor: 'p2', score: 0.9, quote: '重点观看 20:40–33:10 段…三种失效对应的温度曲线形态' },
          { file: 'd2', anchor: 'p4', score: 0.84, quote: '第一周不安排独立操作任何设备…须在有资质人员监护下进行' },
          { file: 'd5', anchor: 'p2', score: 0.79, quote: '班前点检 8 项必查：油位、气压、急停按钮、安全光栅、润滑、异响、泄漏、紧固' }
        ]
      }
    ]
  },
  {
    id: 'c2', title: '注塑机料筒温度异常怎么排查', group: '今天', sub: '4 条消息 · 14:38',
    rec: ['d3', 'd4', 'd7'],
    messages: [
      { role: 'user', text: '3 号注塑机料筒温度最近老报警，我应该按什么步骤查？' },
      {
        role: 'ai',
        html: `<p>按 <strong>SOP-ME-017 第 4.2 节</strong>的「排查四步法」来，不要凭感觉拆<sup class="cite" data-file="d3" data-anchor="p2">1</sup>：</p>
        <ol>
          <li><strong>记录</strong>报警代码与当时的工艺参数（设定/实际温度、生产周期）；</li>
          <li><strong>查热电偶</strong>：看接线与插入深度，用万用表测阻值判断是否损坏；</li>
          <li><strong>查加热圈</strong>：是否断路或接地，测各段电流；</li>
          <li><strong>查水路</strong>：冷却水是否堵塞，温控表 PID 参数是否漂移。</li>
        </ol>
        <p>给你一个提效的<strong>优先级</strong>：按历史工单统计，热电偶松动或老化占 <strong>42%</strong>、加热圈损坏 28%、水路结垢 15%、PID 漂移 10%。<strong>先查热电偶，就能覆盖近一半场景</strong><sup class="cite" data-file="d3" data-anchor="p3">2</sup>。</p>
        <div class="path-card">
          <h4><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2 4 6v6c0 5 3.4 9.2 8 10 4.6-.8 8-5 8-10V6l-8-4Z"/></svg>顺带把这个知识点学透</h4>
          <div class="step"><div class="step-n">学</div><div class="step-b"><div class="step-t">课件第 4 章 · 温度控制系统的组成</div><div class="step-d">理解「感知—执行—决策—散热」闭环，就明白四步法为什么这样排</div></div></div>
          <div class="step"><div class="step-n">看</div><div class="step-b"><div class="step-t">视频 ME-203 第 3 讲 · 20:40–33:10</div><div class="step-d">三台实机演示三种失效模式对应的温度曲线</div></div></div>
          <div class="step"><div class="step-n">练</div><div class="step-b"><div class="step-t">随堂 5 题 + 实操：热电偶更换与阻值测量</div><div class="step-d">≥80 分通过，笔记上传 MES 学习中心</div></div></div>
        </div>
        <p style="margin-top:12px">⚠️ 两条硬要求：作业前<strong>停机、挂牌上锁（LOTO）</strong>；严禁带电拆加热圈端子，高温区必须戴隔热手套和护目镜<sup class="cite" data-file="d3" data-anchor="p1">3</sup><sup class="cite" data-file="d3" data-anchor="q1">4</sup>。</p>`,
        cites: [
          { file: 'd3', anchor: 'p2', score: 0.97, quote: '排查四步法：第一步记录报警代码…第四步检查冷却水路与温控表参数' },
          { file: 'd3', anchor: 'p3', score: 0.94, quote: '热电偶松动或老化 42%、加热圈损坏 28%、冷却水路结垢 15%' },
          { file: 'd3', anchor: 'p1', score: 0.86, quote: '作业前必须停机、挂牌上锁（LOTO）' },
          { file: 'd4', anchor: 'p2', score: 0.82, quote: '先确认感知是否准确…这也是 SOP-ME-017 中四步法的编排逻辑' }
        ]
      },
      { role: 'user', text: '查完之后要做什么记录吗？直接修好就行了吧？' },
      {
        role: 'ai',
        html: `<p>不行，<strong>必须闭环</strong>。SOP 要求填《设备异常处理单》，写明报警代码、根因、更换配件编号和处理结果，并在 MES 里闭环工单；<strong>未闭环的工单不得跨班次移交</strong><sup class="cite" data-file="d3" data-anchor="p4">1</sup>。</p>
        <p>点检侧也是同一套逻辑，六步走完才算数：发现异常 → 现场挂牌 → 填报异常单 → 维修处理 → 维修人签字 → 点检人复检确认 → 归档<sup class="cite" data-file="d5" data-anchor="p3">2</sup>。</p>
        <p>再提醒两个高频扣分点：记录<strong>不空项、不代签、不事后补填</strong>，每项要写实测值或明确状态，不能写「/」「同上」<sup class="cite" data-file="d5" data-anchor="p1">3</sup>。任一步骤缺失，月度设备完好率考核会扣分。</p>`,
        cites: [
          { file: 'd3', anchor: 'p4', score: 0.95, quote: '须填写《设备异常处理单》…未闭环的工单不得跨班次移交' },
          { file: 'd5', anchor: 'p3', score: 0.91, quote: '异常处理闭环：…任一步骤缺失视为未闭环' },
          { file: 'd5', anchor: 'p1', score: 0.85, quote: '三不：不空项、不代签、不事后补填' }
        ]
      }
    ]
  },
  {
    id: 'c3', title: 'PPT 制作：车间月度汇报', group: '昨天', sub: '2 条消息 · 17:20',
    rec: ['d6'],
    messages: [
      { role: 'user', text: '车间月度汇报的 PPT 有什么规范吗？我做的总被说「太花哨」。' },
      {
        role: 'ai',
        html: `<p>《车间汇报 PPT 制作规范》里有明确要求，核心是<strong>把装饰让位于信息</strong>：</p>
        <ul>
          <li><strong>一页一个结论</strong>，标题直接写结论（如「3 号线 OEE 环比提升 4.2%」），不要写「生产情况汇报」<sup class="cite" data-file="d6" data-anchor="p1">1</sup>；每页正文 ≤ 6 行、每行 ≤ 20 字。</li>
          <li><strong>数据一律用图表</strong>：趋势→折线、构成→堆叠柱、对比→柱状、占比→饼图（≤5 类）。必须标注单位、数据来源和统计周期<sup class="cite" data-file="d6" data-anchor="p2">2</sup>。</li>
          <li><strong>字号下限</strong>：标题 28 磅、正文 18 磅、图表标签 14 磅；统一企业蓝 #1D4ED8 + 灰 #64748B 双色<sup class="cite" data-file="d6" data-anchor="p3">3</sup>。</li>
          <li><strong>禁止</strong>：渐变背景、艺术字、三种以上强调色。</li>
        </ul>
        <p>结构建议按 <strong>现状 → 问题 → 原因分析 → 对策 → 需要的支持</strong>，五页讲清一件事，比二十页流水账有效得多<sup class="cite" data-file="d6" data-anchor="p4">4</sup>。</p>
        <p>最常见的四个扣分点：整页文字截图、动画过多、数据没标口径、结论和数据对不上。你把当前版本发我，我可以逐页按这四条给你挑问题。</p>`,
        cites: [
          { file: 'd6', anchor: 'p1', score: 0.96, quote: '一页只讲一个结论，标题即结论' },
          { file: 'd6', anchor: 'p2', score: 0.92, quote: '数据优先用图表呈现…必须标注单位、数据来源与统计周期' },
          { file: 'd6', anchor: 'p3', score: 0.88, quote: '字号下限：标题 28 磅，正文 18 磅，图表标签 14 磅' },
          { file: 'd6', anchor: 'p4', score: 0.8, quote: '现状 → 问题 → 原因分析 → 对策 → 需要的支持' }
        ]
      }
    ]
  },
  {
    id: 'c4', title: '用 AI 写设备点检记录', group: '昨天', sub: '2 条消息 · 11:05',
    rec: ['d1', 'd5'],
    messages: [
      { role: 'user', text: '每天写点检记录太费时间了，能用 AI 帮我写规范点吗？' },
      {
        role: 'ai',
        html: `<p>可以，但要守住一条底线：<strong>AI 只能帮你组织语言，不能替你编造实测值</strong>。记录的法律责任在你身上<sup class="cite" data-file="d5" data-anchor="p1">2</sup>。</p>
        <p>推荐用法（对应《AI 学习导师使用指南》的模板思路）<sup class="cite" data-file="d1" data-anchor="p3">1</sup>：</p>
        <ol>
          <li>把<strong>实测值清单</strong>原样喂给它（如「油位 2/3、气压 0.52MPa、无异响、地脚螺栓无松动」）；</li>
          <li>让它按规范格式输出，并明确要求<strong>不得补充未提供的信息</strong>；</li>
          <li>输出后<strong>逐项核对</strong>再签字，异常项必须自己写明现象与临时处置措施<sup class="cite" data-file="d5" data-anchor="p1">2</sup>。</li>
        </ol>
        <p>你可以直接复制这段提示词：</p>
        <p><code>你是设备点检记录助手。我把实测数据发给你，请按《设备点检与日常保养规范 QG/SC-208》的格式整理成班组点检记录，不空项、不代签，不得编造任何我没有提供的数据。数据如下：……</code></p>
        <p>⚠️ 注意：<strong>不空项、不代签、不事后补填</strong>这三条不会因为用了 AI 而豁免，月度考核照样查<sup class="cite" data-file="d5" data-anchor="p3">3</sup>。</p>`,
        cites: [
          { file: 'd1', anchor: 'p3', score: 0.9, quote: '三种推荐提问方式：学什么 / 怎么学 / 学得怎么样' },
          { file: 'd5', anchor: 'p1', score: 0.94, quote: '三不：不空项、不代签、不事后补填' },
          { file: 'd5', anchor: 'p3', score: 0.83, quote: '异常处理闭环…任一步骤缺失视为未闭环' }
        ]
      }
    ]
  },
  { id: 'c5', title: '数控机床日常保养 SOP', group: '前天', sub: '0 条消息' },
  { id: 'c6', title: '受限空间作业规范要点', group: '上周', sub: '0 条消息' }
];

/* ============================================================
   2.5 知识地图（岗位 → 能力域 → 知识点 · 掌握度）
   s: done 已掌握 / doing 在学 / review 待复习 / todo 未学
   ============================================================ */
const S_LABEL = { done: '已掌握', doing: '在学', review: '待复习', todo: '未学' };
const MAP = {
  role: '设备维护岗 · 初级工',
  goal: '目标：中级工',
  week: '转岗第 2 周 · 跟岗阶段',
  domains: [
    { id: 'm1', n: '设备结构认知', kp: [
      { n: '注塑机五大系统', s: 'done', f: 'd7', a: 'p1',
        res: [['d7', 'p1', '00:00–08:20 结构拆解'], ['d4', 'p1', '第 4 章 · 温控四部分']] },
      { n: '料筒与螺杆结构', s: 'doing', f: 'd7', a: 'p1',
        res: [['d7', 'p1', '00:00–08:20 拆解演示'], ['d4', 'p1', '闭环原理']] },
      { n: '温控系统组成与闭环', s: 'doing', f: 'd4', a: 'p1',
        res: [['d4', 'p1', '四部分与闭环'], ['d4', 'p2', '为什么是这个顺序'], ['d7', 'p2', '20:40–33:10 失效实拍']] }
    ]},
    { id: 'm2', n: '故障排查', kp: [
      { n: '温度异常四步法', s: 'doing', f: 'd3', a: 'p2',
        res: [['d3', 'p2', '四步法全文'], ['d7', 'p2', '实拍对照']] },
      { n: '根因概率与排查优先级', s: 'doing', f: 'd3', a: 'p3',
        res: [['d3', 'p3', '根因排序 42/28/15'], ['d4', 'p2', '顺序编排逻辑']] },
      { n: '异常单填写与工单闭环', s: 'todo', f: 'd3', a: 'p4',
        res: [['d3', 'p4', '处理单填写要求'], ['d5', 'p3', '七步闭环']] },
      { n: '液压系统排查', s: 'todo', res: [] }
    ]},
    { id: 'm3', n: '安全规范', kp: [
      { n: '挂牌上锁 LOTO', s: 'done', f: 'd3', a: 'p1',
        res: [['d3', 'p1', '作业前硬要求'], ['d2', 'p3', '第一周红线']] },
      { n: '高温作业防护', s: 'review', f: 'd3', a: 'q1',
        res: [['d3', 'q1', '安全提示条款'], ['d7', 'p2', '高温实拍']] },
      { n: '受限空间作业要求', s: 'todo', f: 'd8', a: 'p1',
        res: [['d8', 'p1', '先通风再检测后作业'], ['d8', 'p2', '监护与 30 分钟复测']] }
    ]},
    { id: 'm4', n: '点检与保养', kp: [
      { n: '班前点检 8 项', s: 'doing', f: 'd5', a: 'p2',
        res: [['d5', 'p2', '8 项必查清单'], ['d7', 'p1', '设备结构对照']] },
      { n: '记录三不原则', s: 'todo', f: 'd5', a: 'p1',
        res: [['d5', 'p1', '不空项/不代签/不补填'], ['d1', 'p3', 'AI 提效写法']] },
      { n: '异常处理闭环流程', s: 'todo', f: 'd5', a: 'p3',
        res: [['d5', 'p3', '七步闭环'], ['d3', 'p4', 'MES 工单闭环']] }
    ]},
    { id: 'm5', n: '通用技能', kp: [
      { n: 'AI 导师怎么用', s: 'done', f: 'd1', a: 'p1',
        res: [['d1', 'p1', '三类核心能力'], ['d1', 'p3', '三种提问方式']] },
      { n: '汇报 PPT 规范', s: 'done', f: 'd6', a: 'p1',
        res: [['d6', 'p1', '一页一结论'], ['d6', 'p2', '图表优先']] },
      { n: '设备点检记录提效', s: 'doing', f: 'd1', a: 'p3',
        res: [['d1', 'p3', 'AI 正确用法'], ['d5', 'p1', '三不原则']] }
    ]}
  ]
};

/* 继续上次的学习（首屏第一块） */
const RESUME = [
  { kind: 'kp', dm: 'm2', kp: '温度异常四步法', tip: '上次学到：步骤 2 · 检查热电偶' },
  { kind: 'course', code: 'ME-203', tip: '上次看到：第 3 讲 20:40' }
];

/* 我的课程（考的锚点就挂在这里） */
const COURSES = [
  { code: 'ME-203', n: '注塑机结构原理与常见故障', tag: '视频', cls: 'v', p: 3, t: 8, next: '第 4 讲 · 液压系统与压力控制', due: '9/18 前', exam: 5, f: 'd7' },
  { code: 'AQ-101', n: '车间安全与作业规范（必修）', tag: '必修', cls: 'r', p: 2, t: 4, next: '第 3 讲 · 受限空间作业', due: '9/25 前', exam: 4, f: 'd8' },
  { code: 'ME-117', n: '设备点检与保养实务', tag: '混合', cls: 'm', p: 6, t: 6, next: '已完成全部课程', due: '', exam: 0, f: 'd5', pass: 92 },
  { code: 'GM-052', n: '高效汇报与 PPT 制作', tag: '选修', cls: 'e', p: 1, t: 5, next: '第 2 讲 · 一页一结论', due: '', exam: 0, f: 'd6' }
];

/* 推荐问题（空会话宫格 + 输入框浮层共用） */
const ICONS = {
  spark: '<path d="M12 2v4M12 18v4M2 12h4M18 12h4"/><circle cx="12" cy="12" r="4"/>',
  wrench: '<path d="M14.7 6.3a4 4 0 0 0 5 5l-9.4 9.4a2.4 2.4 0 0 1-3.4-3.4Z"/><path d="m14.7 6.3 3-3 3 3-3 3"/>',
  slide: '<rect x="3" y="4" width="18" height="14" rx="2"/><path d="M8 9h8M8 13h5"/>',
  path: '<path d="M3 12h4l3 8 4-16 3 8h4"/>',
  ai: '<path d="M12 2a4 4 0 0 1 4 4v1a4 4 0 0 1-8 0V6a4 4 0 0 1 4-4Z"/><path d="M5 20a7 7 0 0 1 14 0"/>',
  doc: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/>',
  resume: '<circle cx="12" cy="12" r="9"/><path d="M10.4 8.6 15.6 12l-5.2 3.4Z"/>',
  map: '<path d="M9 4 3 6.2v13.6L9 17.6l6 2.2 6-2.2V4.2l-6 2.2Z"/><path d="M9 4v13.6M15 6.2v13.6"/>'
};
/* 输入框上方的示例问题。
   定位：不是「推荐」，是「示范」——告诉用户这种颗粒度、这种类型的问题都能问，
   降低"我这个问题够不够格问"的心理门槛。
   所以这里只放【查询型】问题（带着问题来的人用）；
   「学什么」类的引导型问题不放这里，它们属于首屏的三个入口卡，避免两套选择结构并列。 */
const ASK_CHIPS = [
  '注塑机料筒温度异常怎么排查',
  '受限空间作业有哪些硬性要求',
  '用 AI 帮我写设备点检记录',
  '车间汇报 PPT 有什么规范',
  '液压系统压力不足一般是什么原因',
  '点检发现异常后工单怎么填'
];

/* 首屏 hero 的引导动作：引导型问题，走轻链接而不是卡片 */
const HERO_ACTS = [
  { q: '如何使用 AI 导师学习', t: '第一次用？看它能做什么' },
  { q: '我想考中级工，该怎么规划', t: '看我的成长路径' }
];
const svgFor = (k, s = 14) =>
  `<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${ICONS[k] || ICONS.spark}</svg>`;

/* 新提问的模拟回复 */
const REPLY_POOL = [
  {
    html: `<p>这个问题我按「<strong>学什么 → 怎么学 → 怎么检验</strong>」拆给你。</p>
    <div class="path-card">
      <h4><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12h4l3 8 4-16 3 8h4"/></svg>建议学习路径</h4>
      <div class="step"><div class="step-n">学</div><div class="step-b"><div class="step-t">先建立概念框架</div><div class="step-d">看对应课件章节，知道这个系统由哪几部分组成</div></div></div>
      <div class="step"><div class="step-n">看</div><div class="step-b"><div class="step-t">再看现场实拍视频</div><div class="step-d">把抽象原理和真实设备对上号</div></div></div>
      <div class="step"><div class="step-n">练</div><div class="step-b"><div class="step-t">对照 SOP 实操</div><div class="step-d">有资质人员在场监护，按步骤走一遍</div></div></div>
      <div class="step"><div class="step-n">考</div><div class="step-b"><div class="step-t">随堂测验 + 实操考核</div><div class="step-d">≥80 分通过，记录进入个人学习档案</div></div></div>
    </div>
    <p style="margin-top:12px">这个「概念 → 实拍 → 实操 → 考核」的闭环，是制造学院对所有岗位课程统一采用的编排方式<sup class="cite" data-file="d1" data-anchor="p1">1</sup>。在具体执行上，路径的周次安排和达标标准以岗位成长路径图为准<sup class="cite" data-file="d2" data-anchor="p1">2</sup>。</p>
    <p>需要我针对你的岗位把这条路径细化到每一周吗？把你的<strong>岗位名称、当前等级、目标等级</strong>告诉我即可<sup class="cite" data-file="d1" data-anchor="p2">3</sup>。</p>`,
    cites: [
      { file: 'd1', anchor: 'p1', score: 0.92 },
      { file: 'd2', anchor: 'p1', score: 0.89 },
      { file: 'd1', anchor: 'p2', score: 0.81 }
    ]
  },
  {
    html: `<p>先给结论：<strong>查故障要按 SOP 的顺序走，不要凭经验跳步</strong>。</p>
    <p>原因在于，SOP 的排查顺序是按<strong>历史工单的根因概率</strong>排的，跳步会让你在低频原因上浪费大量时间<sup class="cite" data-file="d3" data-anchor="p3">1</sup>。</p>
    <ul>
      <li>作业前：<strong>停机、挂牌上锁（LOTO）</strong>，这是硬要求，没有例外<sup class="cite" data-file="d3" data-anchor="p1">2</sup>；</li>
      <li>排查中：先记录报警代码与工艺参数，再从<strong>感知环节</strong>开始逐级验证<sup class="cite" data-file="d3" data-anchor="p2">3</sup><sup class="cite" data-file="d4" data-anchor="p2">4</sup>；</li>
      <li>处理后：填《设备异常处理单》并在 MES 闭环工单，<strong>未闭环不得跨班次移交</strong><sup class="cite" data-file="d3" data-anchor="p4">5</sup>。</li>
    </ul>
    <p>配套的这两份资料建议按顺序看：课件先建立闭环概念<sup class="cite" data-file="d4" data-anchor="p1">6</sup>，再看第 3 讲视频里 20:40 之后的三台实机演示<sup class="cite" data-file="d7" data-anchor="p2">7</sup>。</p>`,
    cites: [
      { file: 'd3', anchor: 'p3', score: 0.95 },
      { file: 'd3', anchor: 'p1', score: 0.88 },
      { file: 'd3', anchor: 'p2', score: 0.93 },
      { file: 'd4', anchor: 'p2', score: 0.85 },
      { file: 'd3', anchor: 'p4', score: 0.82 },
      { file: 'd4', anchor: 'p1', score: 0.78 },
      { file: 'd7', anchor: 'p2', score: 0.8 }
    ]
  }
];

/* ============================================================
   3. 渲染
   ============================================================ */
const $ = s => document.querySelector(s);
const convListEl = $('#convList');
const chatInner = $('#chatInner');
const chatScroll = $('#chatScroll');
const workspace = $('#workspace');
const splitter = $('#splitter');
const reader = $('#reader');
const libView = $('#libView');
const docView = $('#docView');
const input = $('#input');
const sendBtn = $('#send');

const KIND_COLOR = {
  't-pdf': '#ef4444', 't-doc': '#2563eb', 't-ppt': '#f59e0b',
  't-sop': '#0d9488', 't-video': '#8b5cf6', 't-gf': '#ea580c'
};

const AI_AVATAR = `<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a4 4 0 0 1 4 4v1a4 4 0 0 1-8 0V6a4 4 0 0 1 4-4Z"/><path d="M5 20a7 7 0 0 1 14 0"/></svg>`;
const isMobile = () => window.innerWidth <= 860;

let currentConv = CONVS[0];
let replyIdx = 0;
let currentFile = null;

/* ---------- 左栏会话列表 ---------- */
function renderConvs() {
  convListEl.innerHTML = '';
  let group = '';
  CONVS.forEach(c => {
    if (c.group !== group) {
      group = c.group;
      const g = document.createElement('div');
      g.className = 'conv-group';
      g.textContent = group;
      convListEl.appendChild(g);
    }
    const el = document.createElement('div');
    el.className = 'conv' + (c.active ? ' active' : '');
    el.innerHTML = `
      <span class="conv-ico">
        <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2Z"/></svg>
      </span>
      <div class="conv-main">
        <div class="conv-title">${c.title}</div>
        <div class="conv-sub">${c.study ? '<span class="conv-tag">学习中</span>' : ''}${c.sub}</div>
      </div>
      <button class="conv-del" title="删除会话">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>
      </button>`;
    el.onclick = e => {
      if (e.target.closest('.conv-del')) return;
      CONVS.forEach(x => x.active = false);
      c.active = true;
      currentConv = c;
      renderConvs();
      renderChat();
      showLib();
      closeSidebar();
    };
    convListEl.appendChild(el);
  });
}

/* ---------- 中间会话 ---------- */
function buildSources(cites) {
  if (!cites || !cites.length) return '';
  const items = cites.map(c => {
    const f = FILES[c.file];
    return `<button class="src" data-file="${c.file}" data-anchor="${c.anchor}">
      <span class="src-ico ${f.cls}">${f.kind}</span>
      <span class="src-name">${f.name}</span>
      <span class="src-score">${Math.round(c.score * 100)}%</span>
    </button>`;
  }).join('');
  return `<div class="sources">
    <div class="sources-head">
      <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/></svg>
      引用来源 · ${cites.length} 处
    </div>
    <div class="src-list">${items}</div>
  </div>`;
}

function msgHTML(m, i) {
  if (m.role === 'user') {
    const files = (m.files || []).map(a =>
      `<span class="at-show">${AT_ICO[a.k] || ''}${escapeHTML(a.n)}</span>`).join('');
    return `<div class="msg user">
      <div class="msg-avatar">我</div>
      <div class="msg-col">
        ${files ? `<div class="at-show-row">${files}</div>` : ''}
        <div class="bubble"><p style="margin:0">${escapeHTML(m.text)}</p></div>
      </div>
    </div>`;
  }
  if (m.pending) {
    return `<div class="msg ai">
      <div class="msg-avatar">${AI_AVATAR}</div>
      <div class="msg-col">
        <div class="thinking-label">正在检索企业知识库并组织答案…</div>
        <div class="bubble" style="display:inline-block"><div class="typing"><i></i><i></i><i></i></div></div>
      </div>
    </div>`;
  }
  return `<div class="msg ai" data-i="${i}">
    <div class="msg-avatar">${AI_AVATAR}</div>
    <div class="msg-col">
      <div class="bubble">${m.html}${buildSources(m.cites)}</div>
      <div class="msg-actions">
        <button data-act="copy"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-1-1V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg><span class="bt">复制</span></button>
        <button data-act="regen"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg><span class="bt">重新生成</span></button>
        <button data-act="list"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg><span class="bt">加入学习清单</span></button>
        <span class="ma-sep"></span>
        <button data-act="good" class="fb${m.fb === 'good' ? ' on' : ''}" title="这个回答有用"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 10v12"/><path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z"/></svg><span class="bt">有用</span></button>
        <button data-act="bad" class="fb${m.fb === 'bad' ? ' on' : ''}" title="这个回答没用"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 14V2"/><path d="M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22h0a3.13 3.13 0 0 1-3-3.88Z"/></svg><span class="bt">没用</span></button>
      </div>
    </div>
  </div>`;
}

function renderChat() {
  currentConv.messages = currentConv.messages || [];
  $('#convTitle').textContent = currentConv.title;
  const msgs = currentConv.messages;
  const citeSet = new Set();
  msgs.forEach(m => (m.cites || []).forEach(c => citeSet.add(c.file)));
  $('#tbCount').textContent = msgs.filter(m => !m.pending).length + ' 条消息';
  $('#tbCite').textContent = '引用 ' + citeSet.size + ' 份文件';

  chatInner.innerHTML = studyBarHTML() + (msgs.length
    ? `<div class="day"><span>${currentConv.group}</span></div>` + msgs.map((m, i) => msgHTML(m, i)).join('')
    : startHTML());
  bindCites();
  bindStart();
  bindSteps();
  renderLib();
  if (msgs.length) chatScroll.scrollTop = chatScroll.scrollHeight;
  else chatScroll.scrollTop = 0;
}

function escapeHTML(s) {
  return s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

/* ---------- 资源行（地图 / 会话共用） ---------- */
function resHTML(r) {
  const f = FILES[r[0]];
  if (!f) return '';
  return `<button class="res" data-f="${r[0]}" data-a="${r[1] || ''}">
    <span class="res-ico ${f.cls}">${f.kind}</span>
    <span class="res-b"><span class="res-n">${f.name}</span><span class="res-h">${r[2]}</span></span>
    <span class="res-go">原文</span>
  </button>`;
}

/* ---------- 空会话首屏：学习起点（继续 / 知识地图 / 选课 / 推荐问题） ---------- */
function startHTML() {
  const s = countMap();
  const hero = `<div class="st-hero">
    <div class="st-hero-l">
      <h2>今天想学点什么？</h2>
      <p>选一个入口，剩下的学、看、练、考我都安排在这个窗口里，不跳课程页。</p>
      <div class="st-acts">${HERO_ACTS.map(a =>
        `<button class="st-act" data-ask="${escapeHTML(a.q)}">${a.t}
          <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
        </button>`).join('')}</div>
    </div>
    <div class="st-role">
      <div class="sr-t">${MAP.role}</div>
      <div class="sr-g">${MAP.goal}</div>
      <div class="sr-bar">
        <i class="a" style="width:${s.done / s.total * 100}%"></i>
        <i class="b" style="width:${s.doing / s.total * 100}%"></i>
        <i class="c" style="width:${s.review / s.total * 100}%"></i>
      </div>
      <div class="sr-m">已掌握 ${s.done}/${s.total} · 在学 ${s.doing} · 待复习 ${s.review}</div>
      <div class="sr-w">${MAP.week}</div>
    </div>
  </div>`;

  const resumeBody = `<div class="st-resume">${RESUME.map(r => {
    if (r.kind === 'course') {
      const c = COURSES.find(x => x.code === r.code);
      return `<div class="st-ru" data-course="${r.code}">
        <span class="ru-ico v">课</span>
        <span class="ru-b"><span class="ru-t">${c.n}</span><span class="ru-d">${r.tip}</span></span>
        <span class="ru-p">${c.p}/${c.t} 讲</span>
      </div>`;
    }
    const d = MAP.domains.find(x => x.id === r.dm);
    return `<div class="st-ru" data-study="${r.dm}|${r.kp}">
      <span class="ru-ico k">点</span>
      <span class="ru-b"><span class="ru-t">${r.kp}</span><span class="ru-d">${r.tip} · ${d.n}</span></span>
      <span class="ru-p">继续</span>
    </div>`;
  }).join('')}</div>`;

  const mapBody = `<div class="st-map">${MAP.domains.map(d => {
    const done = d.kp.filter(k => k.s === 'done').length;
    return `<div class="sdm collapsed" data-dm="${d.id}">
      <button class="sdm-h">
        <span class="sdm-chev"><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg></span>
        <span class="sdm-n">${d.n}</span>
        <span class="sdm-c">${done}/${d.kp.length} 已掌握</span>
      </button>
      <div class="sdm-b">${d.kp.map(k => `
        <div class="skp">
          <div class="skp-h">
            <span class="kp-d s-${k.s}"></span>
            <span class="skp-n">${k.n}</span>
            <span class="skp-s">${S_LABEL[k.s]}</span>
            <span class="skp-r">${(k.res || []).length} 份</span>
            ${(k.res || []).length
              ? `<button class="skp-go" data-study="${d.id}|${k.n}">开始学</button>`
              : `<button class="skp-go ghost" data-ask="${escapeHTML(k.n)}">提问</button>`}
          </div>
          <div class="skp-res">${(k.res || []).map(resHTML).join('')
            || '<div class="skp-none">知识库暂未收录该知识点资源，可先向导师提问</div>'}</div>
        </div>`).join('')}</div>
    </div>`;
  }).join('')}</div>
  <div class="st-foot">5 个能力域，点开看知识点；灰色「未学」就是下一步。再点知识点展开资源。</div>`;

  const courseBody = `<div class="st-courses">${COURSES.map(c => {
    const pct = Math.round(c.p / c.t * 100);
    const fin = c.p >= c.t;
    return `<div class="cs">
      <div class="cs-top"><span class="cs-badge ${c.cls}">${c.tag}</span><span class="cs-code">${c.code}</span></div>
      <div class="cs-name">${c.n}</div>
      <div class="cs-bar${fin ? ' full' : ''}"><i style="width:${pct}%"></i></div>
      <div class="cs-meta"><span>${c.t} 讲 · 已学 ${c.p} 讲</span>${c.due ? `<span class="cs-due">${c.due}</span>` : '<span></span>'}</div>
      <div class="cs-next">${fin ? '已完成' : '下一讲：'}${c.next}</div>
      <div class="cs-acts">
        <button class="mini-btn primary" data-course="${c.code}">${fin ? '复习' : '开始学'}</button>
        <button class="mini-btn" data-f="${c.f}">看原文</button>
      </div>
    </div>`;
  }).join('')}</div>`;

  const ENTRIES = [
    { k: 'resume', ic: 'resume', t: '继续上次的学习', d: '接着断点往下走', body: resumeBody },
    { k: 'map', ic: 'map', t: '从知识地图挑', d: `${MAP.domains.length} 个能力域 · ${s.total} 个知识点`, body: mapBody },
    { k: 'course', ic: 'doc', t: '从培训系统选课', d: 'LMS 已同步 · 86 门在库', body: courseBody }
  ];

  const ent = ENTRIES.map((e, i) => `<div class="ste${i === 0 ? ' open' : ''}" data-e="${e.k}">
    <button class="ste-h">
      <span class="ste-ico">${svgFor(e.ic, 16)}</span>
      <span class="ste-tb"><span class="ste-t">${e.t}</span><span class="ste-d">${e.d}</span></span>
      <span class="ste-chev"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg></span>
    </button>
    <div class="ste-body">${e.body}</div>
  </div>`).join('');

  /* 注意：这里不再放「或者直接问」的问题区。
     示例问题统一收进输入框上方那一行（见 renderQuick），首屏和会话中始终同一处，
     避免同一批问题在页面上出现三次、也避免和三个入口卡抢决策。 */
  return `<div class="start">
    ${hero}
    <div class="st-entries">${ent}</div>
  </div>`;
}

/* ---------- 从入口开启学习会话 ---------- */
function findKp(dmId, kpName) {
  const d = MAP.domains.find(x => x.id === dmId);
  return d ? { domain: d.n, kp: d.kp.find(x => x.n === kpName) } : null;
}

function stepsFor(res) {
  const pick = ks => res.find(r => ks.includes(FILES[r[0]].kind));
  return [
    { n: '学', t: '先建立概念框架', r: pick(['PPT', 'DOC', 'PDF']) || res[0], d: '' },
    { n: '看', t: '再看现场实拍', r: pick(['视频']) || res[1], d: '' },
    { n: '练', t: '对照 SOP 实操', r: pick(['SOP', '规范']) || res[res.length - 1], d: '' },
    { n: '考', t: '随堂测验 · 5 题', r: null, d: '≥80 分通过，成绩回写知识地图' }
  ];
}

function studyIntroHTML(o) {
  const steps = stepsFor(o.res || []);
  return `<p>好，我们围绕 <strong>${o.name}</strong>${o.domain ? `（${o.domain}）` : ''} 开一轮学习。</p>
    <p>我把它拆成四步，<strong>全程在这个窗口里完成</strong>，不用跳转到课程页面。每一步都挂着知识库原文，点「打开」即可在右侧查阅。</p>
    <div class="path-card">
      <h4><svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12h4l3 8 4-16 3 8h4"/></svg>学习路径 · ${o.name}</h4>
      ${steps.map(st => `<div class="step">
        <div class="step-n">${st.n}</div>
        <div class="step-b">
          <div class="step-t">${st.t}</div>
          <div class="step-d">${st.r ? FILES[st.r[0]].name + ' · ' + st.r[2] : st.d}</div>
        </div>
        ${st.r
          ? `<button class="step-go" data-f="${st.r[0]}" data-a="${st.r[1] || ''}">打开</button>`
          : `<button class="step-go exam" data-ask="围绕「${escapeHTML(o.name)}」出 5 道随堂考">开始考</button>`}
      </div>`).join('')}
    </div>
    <p style="margin-top:12px">四步走完，「${o.name}」会标记为<strong>已掌握</strong>，然后我会推荐下一个知识点。中途随时可以打断，进度保留在地图上。</p>`;
}

function studyBarHTML() {
  const st = currentConv.study;
  if (!st) return '';
  return `<div class="study-bar">
    <span class="sb-dot"></span>
    <span class="sb-b"><span class="sb-t">正在学 · ${st.name}</span><span class="sb-s">${st.domain || st.code || ''} · 步骤 1/4</span></span>
    <button class="sb-btn" data-ask="围绕「${escapeHTML(st.name)}」出 5 道随堂考">随堂考</button>
    <button class="sb-btn" id="sbEnd">结束</button>
  </div>`;
}

function startStudy(o) {
  currentConv.title = o.name;
  currentConv.sub = '学习中 · ' + (o.domain || o.code || '');
  currentConv.study = o;
  currentConv.messages = [{
    role: 'ai',
    html: studyIntroHTML(o),
    cites: (o.res || []).slice(0, 3).map(r => ({ file: r[0], anchor: r[1], score: 0.9 }))
  }];
  CONVS.forEach(x => x.active = (x === currentConv));
  renderConvs();
  renderChat();
  showLib();
  if (isMobile()) closeDrawer();
}

function useQuestion(text) {
  input.value = text;
  autoGrow();
  input.focus();
}

/* ---------- 引用交互 ---------- */
function bindCites() {
  chatInner.querySelectorAll('.cite').forEach(el => {
    el.onclick = () => openFile(el.dataset.file, el.dataset.anchor, el);
  });
  chatInner.querySelectorAll('.src').forEach(el => {
    el.onclick = () => openFile(el.dataset.file, el.dataset.anchor, el);
  });
}

function markActive(fileId, anchorId) {
  chatInner.querySelectorAll('.cite.on').forEach(e => e.classList.remove('on'));
  chatInner.querySelectorAll('.src.on').forEach(e => e.classList.remove('on'));
  chatInner.querySelectorAll(`.cite[data-file="${fileId}"][data-anchor="${anchorId}"]`).forEach(e => e.classList.add('on'));
  chatInner.querySelectorAll(`.src[data-file="${fileId}"][data-anchor="${anchorId}"]`).forEach(e => e.classList.add('on'));
}

/* ---------- 右栏：只保留本次会话引用 ---------- */
function renderLib() {
  libView.innerHTML = citeHTML();
  bindLib();
  updateLibHead();
}

function updateLibHead() {
  $('#rdSub').textContent = '本次会话引用 · ' + collectUsed().length + ' 份文件';
}

function countMap() {
  const s = { done: 0, doing: 0, review: 0, todo: 0, total: 0 };
  MAP.domains.forEach(d => d.kp.forEach(k => { s[k.s]++; s.total++; }));
  return s;
}

function citeHTML() {
  const msgs = currentConv.messages || [];
  const used = [];
  msgs.forEach(m => (m.cites || []).forEach(c => {
    if (!used.some(u => u.file === c.file && u.anchor === c.anchor)) used.push(c);
  }));
  const recIds = (currentConv.rec || Object.keys(FILES)).filter(id => FILES[id]);
  const itemHTML = (c, withQuote) => {
    const f = FILES[c.file];
    const on = currentFile === c.file ? ' on' : '';
    const q = (withQuote && c.quote) ? `<div class="lib-quote">${c.quote}</div>` : '';
    return `<div class="lib-item${on}" data-file="${c.file}" data-anchor="${c.anchor || ''}">
      <div class="lib-ico ${f.cls}">${f.kind}</div>
      <div class="lib-main">
        <div class="lib-name">${f.name}</div>
        <div class="lib-desc"><span>${f.desc}</span></div>
        ${q}
      </div>
    </div>`;
  };
  return `<div class="lib-group">
      <div class="lib-group-t"><span>本次会话引用</span><span>${used.length}</span></div>
      ${used.length ? used.map(c => itemHTML(c, true)).join('')
        : `<div class="lib-empty">还没有引用记录<br/>点击回答中的角标，被引用的文件会出现在这里</div>`}
    </div>
    <div class="lib-group">
      <div class="lib-group-t"><span>猜你还需要</span></div>
      ${recIds.slice(0, 3).map(id => itemHTML({ file: id }, false)).join('')}
    </div>`;
}

function bindLib() {
  libView.querySelectorAll('.lib-item').forEach(el => {
    el.onclick = () => openFile(el.dataset.file, el.dataset.anchor || null, null);
  });
}

/* ---------- 右栏：文件详情 ---------- */
function showLib() {
  docView.hidden = true;
  libView.hidden = false;
  $('#rdBack').hidden = true;
  $('#rdTitle').textContent = '知识库';
  $('#rdSub').textContent = '本次会话引用 · ' + collectUsed().length + ' 份文件';
  renderLib();
}

function collectUsed() {
  const set = new Set();
  (currentConv.messages || []).forEach(m => (m.cites || []).forEach(c => set.add(c.file)));
  return [...set];
}

function openFile(fileId, anchorId, trigger) {
  const f = FILES[fileId];
  if (!f) return;
  currentFile = fileId;
  // 面板被收起时，打开引用要自动恢复出来
  workspace.classList.remove('no-reader');
  setToggleActive(true);

  libView.hidden = true;
  docView.hidden = false;
  $('#rdBack').hidden = false;
  $('#rdTitle').textContent = '原文查阅';
  $('#rdSub').textContent = f.desc;

  $('#docBadge').textContent = f.kind;
  $('#docBadge').style.background = KIND_COLOR[f.cls] || '#64748b';
  $('#docName').textContent = f.name;
  $('#docMeta').textContent = f.meta;
  $('#docTags').innerHTML = f.tags.map(t => `<span>${t}</span>`).join('');

  // 本文档在本会话中被引用过的所有位置（常驻高亮）
  const citedSet = citedAnchorsFor(fileId);
  citedList = f.blocks.filter(b => b.id && citedSet.includes(b.id)).map(b => b.id);

  const clsFor = id => {
    if (!id) return '';
    return (citedList.includes(id) ? ' cited' : '') + (id === anchorId ? ' current' : '');
  };

  $('#docContent').innerHTML = f.blocks.map(b => {
    if (b.t === 'video') {
      return `<div class="doc-video">
        <div class="play"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></div>
        <div><div class="vt">${b.title}</div><div class="vs">${b.sub}</div></div>
      </div>`;
    }
    if (b.t === 'h') return `<div class="doc-h">${b.text}</div>`;
    if (b.t === 'quote') return `<div class="doc-quote${clsFor(b.id)}" id="blk-${b.id || 'x' + Math.random().toString(36).slice(2)}">${b.text}</div>`;
    if (b.t === 'note') return `<div class="doc-note">${b.text}</div>`;
    return `<div class="doc-p${clsFor(b.id)}" id="blk-${b.id}">${b.text}</div>`;
  }).join('');

  updateCiteNav(anchorId);
  if (trigger) markActive(fileId, anchorId);
  else renderLib();

  // 移动端：以底部抽屉方式弹出
  if (isMobile()) openDrawer();

  if (anchorId) {
    setTimeout(() => gotoAnchor(anchorId, false), 130);
  } else {
    docView.scrollTop = 0;
  }
}

/* ---- 引用位置常驻高亮与导航 ---- */
let citedList = [];

function citedAnchorsFor(fileId) {
  const set = new Set();
  (currentConv.messages || []).forEach(m => (m.cites || []).forEach(c => {
    if (c.file === fileId && c.anchor) set.add(c.anchor);
  }));
  return [...set];
}

function updateCiteNav(anchorId) {
  const nav = $('#citeNav');
  if (!citedList.length) { nav.hidden = true; return; }
  nav.hidden = false;
  const i = citedList.indexOf(anchorId);
  $('#cnText').textContent = `本文档被引用 ${citedList.length} 处` + (i >= 0 ? ` · 当前第 ${i + 1} 处` : '');
}

function gotoAnchor(anchorId, markChat) {
  docView.querySelectorAll('.current').forEach(e => e.classList.remove('current'));
  const t = document.getElementById('blk-' + anchorId);
  if (t) {
    t.classList.add('cited', 'current');
    docView.scrollTo({ top: Math.max(0, t.offsetTop - 60), behavior: 'smooth' });
    t.classList.add('flash');
    setTimeout(() => t.classList.remove('flash'), 1900);
  }
  updateCiteNav(anchorId);
  if (markChat !== false) markActive(currentFile, anchorId);
}

function stepCite(dir) {
  if (!citedList.length) return;
  const cur = citedList.findIndex(id => document.getElementById('blk-' + id)?.classList.contains('current'));
  const next = citedList[(cur + dir + citedList.length * 2) % citedList.length];
  gotoAnchor(next);
}

/* ---------- 移动端抽屉 ---------- */
function openDrawer() {
  reader.classList.add('open');
  reader.classList.remove('expanded');
}
function closeDrawer() {
  reader.classList.remove('open', 'expanded');
}

/* ============================================================
   4. 拖拽分割线
   ============================================================ */
const DEFAULT_W = 60;
let dragging = false;

function applyWidth(pct) {
  if (window.innerWidth > 1080) workspace.style.setProperty('--chat-w', pct + '%');
  else workspace.style.removeProperty('--chat-w');
}
function saveWidth(pct) {
  try { localStorage.setItem('mentor_chat_w', pct); } catch (e) {}
}

splitter.addEventListener('mousedown', e => {
  dragging = true;
  splitter.classList.add('dragging');
  document.body.classList.add('resizing');
  e.preventDefault();
});
splitter.addEventListener('dblclick', () => { applyWidth(DEFAULT_W); saveWidth(DEFAULT_W); });

document.addEventListener('mousemove', e => {
  if (!dragging) return;
  const rect = workspace.getBoundingClientRect();
  let pct = (e.clientX - rect.left) / rect.width * 100;
  pct = Math.min(76, Math.max(28, pct));
  applyWidth(pct);
});
document.addEventListener('mouseup', () => {
  if (!dragging) return;
  dragging = false;
  splitter.classList.remove('dragging');
  document.body.classList.remove('resizing');
  const cur = workspace.style.getPropertyValue('--chat-w');
  if (cur) saveWidth(parseFloat(cur));
});

/* ============================================================
   5. 输入与发送
   ============================================================ */
function autoGrow() {
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 180) + 'px';
  sendBtn.disabled = !input.value.trim();
}
input.addEventListener('input', autoGrow);
input.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
});

function nowTime() {
  const d = new Date();
  return `${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`;
}

function send() {
  const text = input.value.trim();
  if (!text) return;
  $('#kbPop').hidden = true;
  currentConv.messages = currentConv.messages || [];
  currentConv.messages.push({ role: 'user', text, files: attachChips.slice() });
  attachChips = [];
  renderAttach();
  currentConv.messages.push({ role: 'ai', pending: true });
  input.value = ''; autoGrow();
  renderChat();

  setTimeout(() => {
    currentConv.messages.pop();
    const reply = REPLY_POOL[replyIdx % REPLY_POOL.length];
    replyIdx++;
    currentConv.messages.push({ role: 'ai', html: reply.html, cites: reply.cites });
    renderChat();
  }, 1500);
}
sendBtn.onclick = send;

/* 示例问题：输入框上方常驻一行。
   首屏和会话中用的是同一处、同一份数据——不再出现「首屏三处、有会话又一处」的重复。 */
function renderQuick() {
  $('#qrChips').innerHTML = ASK_CHIPS.map(q =>
    `<button data-q="${escapeHTML(q)}">${q}</button>`).join('');
  $('#qrChips').querySelectorAll('button').forEach(b => {
    b.onclick = () => useQuestion(b.dataset.q);
  });
}

/* 首屏「学习起点」：继续 / 地图 / 选课 三个入口 */
function bindStart() {
  /* 入口卡手风琴：一次只展开一个 */
  const syncH = box => {
    const body = box.querySelector('.ste-body');
    if (!body) return;
    body.style.maxHeight = box.classList.contains('open') ? body.scrollHeight + 'px' : '0px';
  };
  const syncOwner = el => {
    const box = el.closest('.ste');
    if (box) syncH(box);
  };
  chatInner.querySelectorAll('.ste').forEach(syncH);
  chatInner.querySelectorAll('.ste-h').forEach(el => {
    el.onclick = () => {
      const box = el.parentElement;
      const willOpen = !box.classList.contains('open');
      chatInner.querySelectorAll('.ste').forEach(o => { o.classList.remove('open'); syncH(o); });
      if (willOpen) { box.classList.add('open'); syncH(box); }
    };
  });

  chatInner.querySelectorAll('.sdm-h').forEach(el => {
    el.onclick = () => { el.parentElement.classList.toggle('collapsed'); syncOwner(el); };
  });
  chatInner.querySelectorAll('.skp-h').forEach(el => {
    el.onclick = e => {
      if (e.target.closest('button')) return;
      el.parentElement.classList.toggle('open');
      syncOwner(el);
    };
  });
  chatInner.querySelectorAll('.res').forEach(el => {
    el.onclick = () => openFile(el.dataset.f, el.dataset.a || null, null);
  });
  chatInner.querySelectorAll('[data-study]').forEach(el => {
    el.onclick = e => {
      e.stopPropagation();
      const [dm, name] = el.dataset.study.split('|');
      const hit = findKp(dm, name);
      if (hit && hit.kp) startStudy({ kind: 'kp', domain: hit.domain, name: hit.kp.n, res: hit.kp.res || [] });
    };
  });
  chatInner.querySelectorAll('[data-course]').forEach(el => {
    el.onclick = e => {
      e.stopPropagation();
      const c = COURSES.find(x => x.code === el.dataset.course);
      if (!c) return;
      startStudy({
        kind: 'course', code: c.code, name: c.n, domain: '课程 ' + c.code,
        res: [['d7', 'p1', '课程视频'], [c.f, 'p1', '配套资料']].filter(r => FILES[r[0]])
      });
    };
  });
  chatInner.querySelectorAll('[data-ask]').forEach(el => {
    el.onclick = e => { e.stopPropagation(); useQuestion(el.dataset.ask); };
  });
  const end = chatInner.querySelector('#sbEnd');
  if (end) end.onclick = () => {
    delete currentConv.study;
    currentConv.sub = '已暂停 · ' + nowTime();
    renderConvs();
    renderChat();
  };
}

/* 学习路径卡里的「打开 / 开始考」 */
function bindSteps() {
  chatInner.querySelectorAll('.step-go').forEach(el => {
    el.onclick = () => {
      if (el.dataset.f) openFile(el.dataset.f, el.dataset.a || null, null);
      else if (el.dataset.ask) useQuestion(el.dataset.ask);
    };
  });
}

/* ============================================================
   6. 顶部 / 侧栏 / 面板开关
   ============================================================ */
/* 输入框「+」菜单：上传 / 拍照 / 引用知识库（demo 以附件 chip 呈现闭环） */
let attachChips = [];
const PLUS_ACTS = {
  ppUpload: { n: '注塑机操作规程.pdf', k: 'file' },
  ppPhoto: { n: '设备铭牌照片.jpg', k: 'photo' },
  ppLib: { n: 'SOP-ME-017 · 温度异常四步法', k: 'lib' }
};
const AT_ICO = {
  file: '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/></svg>',
  photo: '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="12" cy="12" r="3.5"/></svg>',
  lib: '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5V5a2 2 0 0 1 2-2h13v18H6a2 2 0 0 1-2-2Z"/><path d="M8 7h7M8 11h7"/></svg>'
};
function renderAttach() {
  const row = $('#attachRow');
  row.hidden = attachChips.length === 0;
  row.innerHTML = attachChips.map((a, i) =>
    `<span class="at-chip">${AT_ICO[a.k] || ''}${a.n}<button title="移除" data-i="${i}"><svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button></span>`).join('');
  row.querySelectorAll('button').forEach(b => {
    b.onclick = () => { attachChips.splice(+b.dataset.i, 1); renderAttach(); };
  });
}
$('#plusBtn').onclick = e => { e.stopPropagation(); $('#plusPop').hidden = !$('#plusPop').hidden; };
$('#plusPop').onclick = e => e.stopPropagation();
Object.keys(PLUS_ACTS).forEach(id => {
  $('#' + id).onclick = () => {
    attachChips.push(PLUS_ACTS[id]);
    $('#plusPop').hidden = true;
    renderAttach();
    input.focus();
  };
});

/* 语音输入（车间场景刚需：手上有油、戴手套、在设备边走动时打字比说话难）
   demo 用 2.6s 模拟「说完自动结束」的节奏。真实接入点：
   const rec = new webkitSpeechRecognition(); rec.lang = 'zh-CN'; rec.continuous = false;
   rec.onresult = e => { input.value = e.results[0][0].transcript; autoGrow(); };
   rec.start() / rec.stop() —— 把下面两个函数体换成这两个调用即可。 */
const VOICE_DEMO = '注塑机料筒温度又飘了，帮我看看怎么排查';
const INPUT_PH = input.placeholder;
let voiceTimer = null, listening = false;
function startVoice() {
  listening = true;
  $('#micBtn').classList.add('rec');
  input.placeholder = '正在聆听…说完再点一次，或等它自动结束';
  voiceTimer = setTimeout(stopVoice, 2600);
}
function stopVoice() {
  clearTimeout(voiceTimer);
  listening = false;
  $('#micBtn').classList.remove('rec');
  input.placeholder = INPUT_PH;
  input.value = VOICE_DEMO;
  autoGrow();
  input.focus();
}
$('#micBtn').onclick = () => (listening ? stopVoice() : startVoice());

/* 知识库范围：浮层多选 */
const KB_OPTS = [
  { id: 'all', t: '全部知识库', c: '1,284 份 · 课程 + SOP + 规范' },
  { id: 'sop', t: 'SOP 与作业指导书', c: '412 份 · 设备管理部' },
  { id: 'gf', t: '安全与质量规范', c: '331 份 · 强制标准' },
  { id: 'course', t: '岗位课程与视频', c: '86 门 · 制造学院' },
  { id: 'note', t: '我的笔记与收藏', c: '24 份 · 个人' }
];
let kbSel = new Set(['all']);

function renderKbOpts() {
  $('#kbOpts').innerHTML = KB_OPTS.map(o => `<button class="kb-opt${kbSel.has(o.id) ? ' on' : ''}" data-id="${o.id}">
    <span class="kb-box"><svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="m20 6-11 11-5-5"/></svg></span>
    <span><span class="kb-t">${o.t}</span><span class="kb-c">${o.c}</span></span>
  </button>`).join('');
  $('#kbOpts').querySelectorAll('.kb-opt').forEach(b => {
    b.onclick = () => {
      const id = b.dataset.id;
      if (id === 'all') { kbSel = new Set(['all']); }
      else {
        kbSel.delete('all');
        kbSel.has(id) ? kbSel.delete(id) : kbSel.add(id);
        if (!kbSel.size) kbSel = new Set(['all']);
      }
      renderKbOpts();
    };
  });
  $('#kbCount').textContent = kbSel.has('all') ? '' : `已选 ${kbSel.size} 类`;
}
function applyKb() {
  const label = kbSel.has('all') ? '全部知识库'
    : kbSel.size === 1 ? KB_OPTS.find(o => o.id === [...kbSel][0]).t
      : `已选 ${kbSel.size} 类`;
  $('#kbLabel').textContent = label;
  $('#kbPop').hidden = true;
}
$('#kbBtn').onclick = e => {
  e.stopPropagation();
  $('#kbPop').hidden = !$('#kbPop').hidden;
};
$('#kbPop').onclick = e => e.stopPropagation();
$('#kbApply').onclick = applyKb;
$('#kbReset').onclick = () => { kbSel = new Set(['all']); renderKbOpts(); applyKb(); };
document.addEventListener('click', () => { $('#kbPop').hidden = true; $('#plusPop').hidden = true; });

/* ---------- 消息级操作：复制 / 重新生成 / 加入清单 / 有用没用 ----------
   用事件委托绑在 chatInner 上，只绑一次，消息重渲染不用重新绑定 */
function htmlToText(h) {
  const d = document.createElement('div');
  d.innerHTML = h;
  return (d.innerText || d.textContent || '').replace(/\n{3,}/g, '\n\n').trim();
}
function copyText(t) {
  if (navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(t);
  const ta = document.createElement('textarea');
  ta.value = t;
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); } catch (_) {}
  ta.remove();
  return Promise.resolve();
}
function flashBtn(btn, text, cls) {
  const s = btn.querySelector('.bt');
  if (!s) return;
  const old = s.textContent;
  s.textContent = text;
  btn.classList.add(cls || 'done');
  setTimeout(() => { s.textContent = old; btn.classList.remove(cls || 'done'); }, 1400);
}
chatInner.addEventListener('click', e => {
  const btn = e.target.closest('.msg-actions button');
  if (!btn) return;
  const box = btn.closest('.msg');
  const m = currentConv.messages[+box.dataset.i];
  if (!m || m.pending) return;
  const act = btn.dataset.act;

  if (act === 'copy') {
    const bubble = box.querySelector('.bubble');
    copyText(htmlToText(bubble ? bubble.innerHTML : '')).then(() => flashBtn(btn, '已复制'));
    return;
  }

  if (act === 'regen') {
    m.pending = true;
    renderChat();
    setTimeout(() => {
      const r = REPLY_POOL[replyIdx % REPLY_POOL.length];
      replyIdx++;
      m.pending = false;
      m.html = r.html;
      m.cites = r.cites;
      delete m.fb;
      renderChat();
    }, 1400);
    return;
  }

  if (act === 'list') {
    m.listed = !m.listed;
    btn.classList.toggle('on', m.listed);
    flashBtn(btn, m.listed ? '已加入' : '已移出');
    return;
  }

  if (act === 'good' || act === 'bad') {
    m.fb = m.fb === act ? null : act;   // 再点一次取消
    box.querySelectorAll('.fb').forEach(b => b.classList.toggle('on', b.dataset.act === m.fb));
    return;
  }
});

/* 引用位置导航 */
$('#cnPrev').onclick = () => stepCite(-1);
$('#cnNext').onclick = () => stepCite(1);

function newConv() {
  const c = { id: 'c' + Date.now(), title: '新的学习会话', group: '今天', sub: '0 条消息 · 刚刚', active: true, messages: [] };
  CONVS.forEach(x => x.active = false);
  CONVS.unshift(c);
  currentConv = c;
  renderConvs();
  renderChat();
  showLib();
  if (isMobile()) closeDrawer();
  if (isMobile()) closeSidebar();
  input.focus();
}
$('#btnNew').onclick = newConv;
$('#tbNew').onclick = newConv;   // 顶部入口：手机端左栏收在抽屉里时不用先拉抽屉

function openSidebar() { $('#sidebar').classList.add('open'); $('#scrim').classList.add('show'); }
function closeSidebar() { $('#sidebar').classList.remove('open'); $('#scrim').classList.remove('show'); }
$('#hamburger').onclick = openSidebar;
$('#sbClose').onclick = closeSidebar;
$('#scrim').onclick = closeSidebar;

/* 知识面板显隐：桌面用 no-reader，移动用抽屉 */
function setToggleActive(on) {
  $('#toggleReader').classList.toggle('off', !on);
}
$('#toggleReader').onclick = () => {
  if (isMobile()) {
    const open = !reader.classList.contains('open');
    open ? openDrawer() : closeDrawer();
    setToggleActive(open);
  } else {
    const hidden = workspace.classList.toggle('no-reader');
    setToggleActive(!hidden);
  }
};
$('#rdClose').onclick = () => {
  if (isMobile()) closeDrawer(); else workspace.classList.add('no-reader');
  setToggleActive(false);
};
$('#rdBack').onclick = showLib;
$('#rdExpand').onclick = () => reader.classList.toggle('expanded');
$('#rdGrab').onclick = () => reader.classList.toggle('expanded');

window.addEventListener('resize', () => {
  const openBody = chatInner.querySelector('.ste.open .ste-body');
  if (openBody) openBody.style.maxHeight = openBody.scrollHeight + 'px';
  if (!isMobile()) { reader.classList.remove('open', 'expanded'); }
  if (window.innerWidth > 1080) {
    const saved = parseFloat(localStorage.getItem('mentor_chat_w') || DEFAULT_W);
    applyWidth(saved);
  } else {
    workspace.style.removeProperty('--chat-w');
  }
});

/* ============================================================
   7. 初始化
   ============================================================ */
renderQuick();
renderKbOpts();
renderConvs();
renderChat();
showLib();
autoGrow();
applyWidth(parseFloat(localStorage.getItem('mentor_chat_w') || DEFAULT_W));
