---
name: skill-writer
description: >
  写 skill 与审 skill：新建或重构一份 SKILL.md，或审计已有 skill 的结构与写法质量。
agent_created: true
---

# skill-writer

## Goal

产出一份可被 agent 稳定消费的 skill，或一份针对已有 skill 的审计结论。

范围边界：

- 只管 skill 文档的**结构与写法**——信息怎么分层、指针怎么写、约束放哪、定稿怎么验。不裁决 skill 业务内容本身的取舍与正确性。
- 审计只出结论与修补方向，最终取舍由用户裁决。

## Input

接受任意与 skill 写作相关的输入——一段需求描述（模糊可接受）、一份待改写的 `SKILL.md`、一个已有 skill 目录，或它们的任意组合。

从零新建走全部步骤；审计已有 skill 从步骤三进入。

输入不完整时不猜、只问一次：缺项按分级出报告，见 `references/steps.md` 第一节。

## Workflow

### 步骤一 · 校验输入（模式 B 跳过）

判定工作形态（A 从零新建 / B 审计已有），按 `references/steps.md` 第一节的缺项分级表逐项核，出输入校验报告：阻塞项列全等用户补，可推断项声明默认值后继续，可后置项记入报告步骤二闭环。

完成判据：

- 每个缺项都有归属：阻塞 / 默认值 / 后置
- 阻塞项已补齐，或用户已确认降级

### 步骤二 · 撰写（模式 B 跳过）

以 `assets/SKILL-template.md` 为底建骨架并逐节填写：条件段逐个过保留判据，该删的整节删；各节的写法取 `references/writing-guide.md` 对应节。

完成判据：

- frontmatter 必需字段已按规范填，`name` 与目录名一致
- 分派无悬空：每块内容有去处，每个已建子目录有归属内容
- 全篇无待填占位：字段、ⓘ 提示、条件段空节
- 步骤一的可后置项均已落点——写入正文，或在报告中标注推迟

### 步骤三 · 定稿校验

逐项核机械项——`SKILL.md` 存在、frontmatter 字段、段结构取舍、引用路径、孤儿文件。这一层只放机械可核对的项，需要判断的留给步骤四。清单见 `references/steps.md` 第二节。

完成判据：

- 校验清单无 ❌
- 出现过的 ⚠️ 已修补，或已记录未决原因

### 步骤四 · 审计与迭代

按 `references/audit-questions.md` 的 19 问逐条打标（✅ 合规 / ⚠️ 部分 / ❌ 违规），结论用 `assets/audit-report-template.md` 出。修补后回到步骤三复验；轮次上限与阻塞处理见 `references/steps.md` 第三节。

完成判据：

- 19 问无一漏标
- ⚠️ / ❌ 已修补，或已记录未决原因

## Output

两种交付物按工作形态二选一，落盘至输入校验报告声明的路径（默认 `tmp/<skill-name>/`）：

| 形态 | 交付物 | 结构 |
|---|---|---|
| A | 一个 skill 目录 | `SKILL.md` 按 `assets/SKILL-template.md`，子目录按 `references/writing-guide.md` 放置节 |
| B | 一份审计结论 | 按 `assets/audit-report-template.md` 分支 A |

## Rules

1. 自包含：判据缺口从本 skill 内补齐，不回指其他 skill。
2. 单一真相源：撰写时即按 audit ⑨ 定好每个含义的唯一位置。
3. 确认前不改源文件：审计与改写阶段，修补方案先呈现给用户，确认后才落盘。

## References

- `references/writing-guide.md`：产出物逐节的撰写方法论——放置、frontmatter、Goal、Input/Output、Workflow（步骤划分与完成判据）、Rules（四项检验）、References。步骤二取用。
- `references/steps.md`：三个步骤的细化——缺项分级表（步骤一）、定稿校验清单（步骤三）、迭代机制（步骤四）。步骤一、三、四取用。
- `references/audit-questions.md`：19 问审计透镜，每问配关键问题 + 判据，是判据的权威定义。步骤四取用。
- `assets/SKILL-template.md`：产出 skill 的空模板，含 frontmatter 占位与逐节保留判据。步骤二取用。
- `assets/audit-report-template.md`：审计结论与输入校验报告共用的骨架。步骤一、四取用。
