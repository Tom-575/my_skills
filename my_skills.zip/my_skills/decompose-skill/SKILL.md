---
name: decompose-skill
description: 拆解 SKILL，产出 report 与 checklist 两份文档。当用户要拆解一个 SKILL 时使用。
disable-model-invocation: true
---

# decompose-skill

## Goal

把一份 skill（SKILL.md 及其引用文件）拆解沉淀为两份独立文档：
- **report（`REPORT.md`）**：以 3W+H 为叙述方向讲清该 skill 的本质，How 段萃取其方法论、决策规则、术语与边界陷阱；末尾「问题与缺陷」记录拆解中发现的薄弱处。
- **checklist（`CHECKLIST.md`）**：该 skill 方法论的**决策蒸馏**——沿其执行线列出全部决策点，判据取原文规则，供执行者速查。

边界：以只读方式理解 / 归档任意 skill；产出萃取其方法论、决策规则与边界。

## Workflow

### 步骤 1 · 递归读取
读 `<skill-dir>` 内全部文件（`.md`、`.yaml`、引用资源），读取范围限定在该目录内，按文件实际写法理解。
- 完成：`<skill-dir>` 全部文件内容已在上下文，含显式引用的文件。

### 步骤 2 · 写 report
按 `reference/report-template.md` 的格式骨架写拆解叙述，顺序固定 Who → Why → What → How → 问题与缺陷，How 段萃取方法论。
- 完成：report 草稿齐备——四轴叙述完整，方法论已萃取，「问题与缺陷」已列出。

### 步骤 3 · 蒸馏 checklist
按 `reference/decision-distillation.md` 的四步方法——找决策点 → 按执行线排布 → 判据取原文 → 一句话收束——套 `reference/checklist-template.md` 的格式骨架生成。
- 完成：checklist 草稿齐备——决策点全部落条，每条判据忠实原文，末尾有一句话收束。

### 步骤 4 · 落盘
写入 `<out-dir>/<skill-name>/REPORT.md` 与 `CHECKLIST.md`。
- 完成：`<out-dir>/<skill-name>/` 下存在非空的 REPORT.md 与 CHECKLIST.md。

### 步骤 5 · 校验
逐条核对 checklist 判据与原 skill 原文一致；通读两产物，确认 report 叙述与 checklist 无矛盾。
- 完成：判据已逐条对照原文；「问题与缺陷」已填（无则写「无」）。

## Rules
- **原目录只读**：所有产出写入 `<out-dir>`，原 skill 目录保持原始状态。
- **形状随对象**：report 的叙述分节与 checklist 的执行线分块，由被拆解 skill 自身决定。
- **萃取方法论**：report 聚焦方法论、决策与边界。
- **忠实原文**：checklist 判据取 skill 原文规则，skill 怎么写就怎么记。
- **问题 > 答案**：问题前置、答案附后。

## References
- `reference/report-template.md` — report 格式骨架。
- `reference/decision-distillation.md` — checklist 生成方法论（决策蒸馏）。
- `reference/checklist-template.md` — checklist 格式骨架。
- 实例：`decomposed/to-spec/`（REPORT.md + CHECKLIST.md）。
