# Prompt 生成模板（prompt-template）

由 `prompt-optimizer` 生成模式套用。按 MVP 原则创建：非必要不添加可选字段。

## 结构

```
## Role (可选)
## Goal
## Domain-Knowledge (可选)
## Rule (全局原则，不限步骤；正向陈述，不含"不做什么")
## Workflow (步骤 + 绑步骤的约束；每步带完成判据)
## Reasoning (可选，CoT；复杂判断任务建议开启逐步推理)
## Reference (可选；放 few-shot / 长案例，主文件只引不展开)
## Input-Format (可选)
## Output-Format
## Example (须严格符合 Output-Format)
## Self-Check (可选；产出后业务判据验收)
```

## 字段说明

- **Role（可选）**：智能体的角色设定。
- **Goal**：执行目标。正向陈述"做什么"，不写"不做什么"（反向内容融进对应 Rule）。
- **Domain-Knowledge（可选）**：领域客观常识，先于 Rule 给出。
- **Rule**：全局原则，不限步骤。正向陈述，不含反向"不做什么"清单。
- **Workflow**：步骤序列 + 绑特定步骤的约束；每步带完成判据。Rule 与 Workflow 边界——全局原则进 Rule，绑步骤的进 Workflow，不混。
- **Reasoning（可选，CoT）**：复杂判断 / 易混淆任务建议开启"先打标再提取"等逐步推理；简单抽取不必。
- **Reference（可选）**：存放 few-shot 示例与长案例；主文件只引指针，不展开。
- **Input-Format（可选）**：输入结构说明。
- **Output-Format**：输出结构，必填。Example 须严格符合它。
- **Example**：输出格式的具象化，必须可映射到 Output-Format。
- **Self-Check（可选）**：产出后的验收段，写清三点：
  ① 验什么——列出产出的**业务判据**（如"必填项非空"、"detail 为原话连续片段"）；
  ② 怎么判——每条须为可判定的是/否判据，不写"质量良好"这类主观描述；
  ③ 不过怎么办——重做该步或回退，而非仅提示。
  它只验业务正确性，不验 prompt 自身质量；与 Reasoning（产出前推理）互补、不互替，且勿退化成无推理价值的机械打钩。

## MVP 必填集

生成时最少需包含：`Goal` / `Rule` / `Workflow` / `Output-Format`。
其余字段仅在有实际必要性时添加，不预置空段。
