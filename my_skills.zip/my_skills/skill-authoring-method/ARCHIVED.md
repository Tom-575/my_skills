# 已归档

本目录于 2026-09-03 归档，被 `../skill-writer/` 取代。入口文件已重命名为 `SKILL.md.archived`，系统不再识别它为可调用 skill。

## 保留的两份文件

| 文件 | 性质 | 去向 |
|---|---|---|
| `skill-authoring-method.md` | 撰写规范（四段结构 + 两层质量属性） | **未被继承**。其六维/四维与源文档 `writing-for-agents` 无交集，已废弃；替代物是 `skill-writer/references/quality-levers.md` 的回推表 |
| `writing-for-agents-questions.md` | 19 问审计清单 | **已被继承**。移入 `skill-writer/references/audit-questions.md`，重组为 20 问并补失败样例 |

## 归档原因

同一份源文档 `writing-for-agents` 被提炼成两份产物，保真度差异悬殊：19 问对源杠杆覆盖率约 100%，撰写方法论约 0%（自造体系）。而旧 SKILL.md 的骨架取了后者、透镜用了前者，两套体系无共用概念，无法咬合。

详见 `.workbuddy/memory/2026-09-03.md`。

## 回滚

若需恢复可调用状态，将 `SKILL.md.archived` 改回 `SKILL.md` 即可。
