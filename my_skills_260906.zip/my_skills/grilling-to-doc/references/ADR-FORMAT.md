# ADR Format

One node of the decision tree is an ADR: a decision worth remembering, carrying the reasoning behind it.

## Template

A node is one line of the tree skeleton, with the decision indented under it.

```md
├─ {Number} {Short title of the decision}
│     {1-3 sentences: what's the context, what did we decide, and why.}
│     Rests on: {the fact numbers it leans on}
```

That's it. An ADR can be a single sentence. The value is in recording *that* a decision was made and *why*, not in filling out sections.

## Optional lines

Only include these when they add genuine value. Most ADRs won't need them. Add them as indented lines under the decision.

- **Status** (`proposed | accepted | deprecated | superseded by {number}`): useful when decisions are revisited
- **Considered Options**: only when the rejected alternatives are worth remembering
- **Consequences**: only when non-obvious downstream effects need to be called out

## The gates

All three must hold for an answer to earn a full node:

1. **Hard to reverse**: the cost of changing your mind later is meaningful
2. **Surprising without context**: a later reader will look at the outcome and wonder "why on earth did they do it this way?"
3. **The result of a real trade-off**: there were genuine alternatives and you picked one for specific reasons

An answer missing the gates still writes, as a bare line. Exception: an answer the user asks to record goes up as a full node, unconditionally—the gates are the agent's default judgment, and the user's explicit wish outranks it.

### What qualifies

- **Architectural shape.** "We're using a monorepo." "The write model is event-sourced, the read model is projected into Postgres."
- **Integration patterns between parts.** "Ordering and Billing communicate via domain events, not synchronous HTTP."
- **Choices that carry lock-in.** Database, message bus, auth provider, deployment target. Not every library: just the ones that would take a quarter to swap out.
- **Boundary and scope decisions.** "Customer data is owned by the Customer context; other contexts reference it by ID only." The explicit no-s are as valuable as the yes-s.
- **Deliberate deviations from the obvious path.** "We're using manual SQL instead of an ORM because X." Anything where a reasonable reader would assume the opposite, and which stops the next person from "fixing" something that was deliberate.
- **Constraints not visible in the outcome.** "We can't use AWS because of compliance requirements." "Response times must be under 200ms because of the partner API contract."
- **Rejected alternatives when the rejection is non-obvious.** If you considered GraphQL and picked REST for subtle reasons, record it; otherwise someone will suggest GraphQL again in six months.

These examples come from code. The same rungs apply anywhere else: what counts is the weight of the choice, not whether it was made in a codebase.
