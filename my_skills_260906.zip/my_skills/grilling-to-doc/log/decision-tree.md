# 决策树 · grilling-to-doc

**输出目录**：`my_skills/my_skills/grilling-to-doc/`
**日期**：2026-09-06（第五轮：英文原子自闭环版，primitive 内嵌）

## Tree

```text
├─ 1 形态：重写 [→ 全局]
│    对齐 skill-writing 的模板与依赖模型。
│  │
│  ├─ 1.1 触发场景 [→ description]
│  │    拷问一个计划或设计、且讨论结果需要留档；一分支一触发词。
│  │
│  ├─ 1.2 边界 [→ Goal]
│  │    只管访谈与落盘；是否执行、业务取舍归用户。
│  │
│  ├─ 1.3 步骤划分 [→ Workflow]
│  │    两步——拷问并落盘（循环）、收尾核对。
│  │
│  ├─ 1.4 跨步骤约束 [→ Rules]
│  │    新节点新事实落定即写并报告；改会话前已有的节点先提议。
│  │
│  ├─ 1.5 子目录分派 [→ References + agents/]
│  │    references/ADR-FORMAT.md 收 ADR 判据与格式；agents/openai.yaml 平台元数据。（已核实: F2）
│  │
│  └─ 1.6 交付物骨架 [→ Output]
│       单文件 decision-tree.md，tree 命令式骨架，Tree 在上 Facts 在下，节点即 ADR、事实编号 F1/F2。
│
├─ 2 依赖模型：自闭环 [→ Input / 步骤一]
│    grilling primitive 内嵌自 my_skills/my_skills/grilling，目录拷走即用、零外部依赖；原 Skill tool 调用方案废弃。（明说：原子 + 自闭环）
│  ├─ 2.1 裸节点时序 [→ 步骤一/二]
│  │    三判据没全中的答案也写为裸节点（标题与答案），收尾删无够格后代的——判定从写入时移到收尾时。（默认值，待确认）
│  │
│  └─ 2.2 跨会话矛盾 [→ 步骤一]
│       先提议，经同意后写新节点（挂原位），旧节点加状态：superseded by {新编号}——会话内就地改写，跨会话留痕演化。（默认值，待确认）
│
├─ 3 ADR 门槛 [→ references/ADR-FORMAT]
│     三判据（难逆转 / 无上下文会令人费解 / 真实权衡）全中才成节点，判据抄 domain-modeling；用户要求记录的答案无条件上树。
│  └─ 3.1 悬空引用 [→ 步骤二]
│        收尾删编号事实时同步移除节点里的依据行。（默认值，待确认）
│
├─ 4 收尾清理作用域 [→ 步骤二]
│     本会话写的直接删并报告；会话开始前已有的先提议——对齐 Rules 2，消除"步骤二直接删"与"改既有需确认"的冲突。（默认值，待确认）
│
└─ 5 语言与原子性 [→ 全局]
     英文撰写；每步正文一段话 ≤2 句、完成判据 ≤2 点，出自 skill-writing 的步骤与判据规则。（明说：原子 + 自闭环）
```

## Facts

| # | 事实 | 来源 |
|---|---|---|
| F1 | `grilling` 原语为 model-invoked skill，可被 Skill tool 调用 | 已核实：`skills/skills/productivity/grilling/SKILL.md` 无 disable-model-invocation |
| F2 | `skill-writing` 的依赖模型是「已装即调用」，决策记录落 `log/decision-tree.md`、随 skill 走、不被 SKILL.md 引用 | 已核实：`skill-writing/SKILL.md` Output 节与步骤四 |
| F3 | 本 skill 由 `skills/skills/engineering/grilling-to-doc`（英文叙事式，仍存在于上游仓库结构中）演化而来，两份现已分叉 | 已核实：两目录并存 |

## 未决项

| # | 项 | 阻塞原因 | 处理 |
|---|---|---|---|
| 1 | 双份漂移：`skills/skills/engineering/grilling-to-doc/`（英文叙事式）与本版并存，演化只发生在这里 | 涉及 `skills/` 仓库五处资产（plugin.json、两个 README、docs 页、ask-matt），不属本 skill 内容 | 待用户：以哪份为真相源 |
| 2 | 动态验证：静态审计已过，未跑过真实会话 | AND 之下树的密度、tree 骨架的维护手感、裸节点先写后清的顺滑度，只有实战能验 | 建议：拿一个真要做的决定 grill 一轮 |
