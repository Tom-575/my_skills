---
name: grilling-to-doc
description: >
  Grill a plan or design and write each round's settled results into decision-tree.md: a decision tree (nodes are ADRs) plus numbered facts.
  Use when the user wants a grilling interview and the outcome needs to survive the session.
---

# grilling-to-doc

## Goal

- Interview the user to a shared understanding; every round's settled answers land in the output file before the next round is asked.
- Interview and capture only: whether to act, and every business call, stays with the user.

## Input

- Output directory: named by the user; ask before round one when it was not.
- The file starts empty: read what is already there only by name, when the user hands it to you.

## Output

- `<output-dir>/decision-tree.md`, headed `# {Topic}: {date}`, Tree above Facts. Skeleton:

```md
# {Topic}: {date}

## Tree

├─ 1 {Decision}
│     {1-3 sentences: what's the context, what did we decide, and why.}
│     Rests on: F1
│  ├─ 1.1 {Decision hanging off it}
│  │     {1-3 sentences.}
│  └─ 1.2 {Decision hanging off it}
│        {1-3 sentences.}
│        Rests on: F2
└─ 2 {Independent decision}
      {1-3 sentences.}

## Facts

- F1 {The fact in one line} (source: {file, command output, or the user})
- F2 {The fact in one line} (source: {file, command output, or the user})
```

## Workflow

### Step 1 · Grill and capture (loop)

Grill per the primitive below, capturing each round before asking the next, per the capture rules after it.

> Interview the user relentlessly until you reach a shared understanding. Map this as a **design tree**: every decision branches into the decisions that hang off it.
>
> Work the tree in **rounds**. The **frontier** is every decision whose prerequisites are already settled: the questions you can ask _now_ without guessing at answers you haven't heard yet. Ask the whole frontier in one round: number each question and give your recommended answer. Then wait for the user's answers before the next round.
>
> Format a round like so:
>
> ```
> ❓ **Q1** - **<question title>**: <question body, might be multiple paragraphs, including multiple choices>
>
> ➡️ <your recommended answer>
>
> ---
>
> ❓ **Q2** - **<question title>**: <question body, might be multiple paragraphs, including multiple choices>
>
> ➡️ <your recommended answer>
> ```
>
> Each round the user answers reshapes the tree: settled decisions push the frontier outward and unblock questions that depended on them. Recompute the frontier and ask the next round. A question whose answer depends on another question still open in this round belongs to a _later_ round, not this one.
>
> Finding _facts_ is your job, never the user's. When a frontier question needs a fact from the environment (filesystem, tools, etc.), dispatch a sub-agent to find it; don't ask the user for anything you could look up yourself. Don't block on it: a running exploration is an unsettled prerequisite, so only the questions downstream of it wait for the sub-agent to report; ask the rest of the frontier now. The _decisions_ are the user's: put each to them and wait.
>
> The session is done when the frontier is empty: every branch of the design tree visited, nothing left silently assumed. Do not act on it until the user confirms you have reached a shared understanding.

Capture rules:

- A node is an ADR: all three gates hold, or the user asks to record it. Gates, node format, and what qualifies live in `references/ADR-FORMAT.md`.
- An answer missing the gates still writes, as a bare line (title and answer); close-out deletes bare lines with no qualifying child.
- **Facts** are numbered `F1`, `F2`; nodes point at them with `Rests on: F1`, which keeps a fact propping up several decisions written once. Record one when it answers a frontier question or rules a candidate decision in or out, and re-deriving it would cost real work; what a single grep returns belongs to the environment, not the file.
- This session's nodes amend in place and report. Nodes predating the session: propose first, then a new node at the same spot with the old one marked `Status: superseded by {number}`. A fact contradicting the user goes to the user to rule on. Unresolved conflicts stay out of the file as frontier questions, closed by a ruling or by scope.

Completion criteria:

- The frontier is empty and the user confirms the shared understanding
- Every node maps to one user answer, every numbered fact has a source, no placeholders

### Step 2 · Close

Read the file top to bottom: every node matches the user's last word. Clean up: drop numbered facts no longer cited and stale (removing the dangling `Rests on` lines) and bare lines with no qualifying child — this session's directly with a report, predating ones by proposal; then show the tree.

Completion criteria:

- Nodes match the user's last word, references dangle-free, bare lines cleaned, conflicts closed
- Nothing acted on before the user confirms

## Rules

1. New nodes and facts write on settle, then report.
2. Nodes predating the session: propose first, act on the user's word.

## References

- `references/ADR-FORMAT.md`: the three gates, node template, optional lines, what qualifies. Consult when writing a node.
