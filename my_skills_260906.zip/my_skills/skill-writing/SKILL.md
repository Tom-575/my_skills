---
name: skill-writing
description: Create, rewrite, audit, or repair agent skills when the user asks to design or review a skill.
---

# skill-writing

## Goal

- 产出或改进一个可被 agent 稳定消费的 skill。
- 保留用户对业务、产品和范围的裁决权，只处理 skill 的结构、写法和执行可靠性。

## Input

- 目标 skill 的目录或 `SKILL.md`。
- 用户指定的模式：审计、重写、修补或新建；未指定时，已有 skill 默认审计，缺失的 skill 默认新建。

## Output

- 审计：一份只读审计报告，包含机械检查结果、19 问逐项标记、问题证据、未决项和结论。
- 新建：完整 skill 目录和 `log/decision-tree.md`。
- 重写：更新后的 skill 目录和 `log/decision-tree.md`。
- 修补：修改后的 skill、复审结果和更新后的 `log/decision-tree.md`。

## Workflow

重写模式默认覆盖目标 skill 的整个目录，而不只是 `SKILL.md`。开始前提醒用户这一范围；如果用户只想修改入口文件，必须明确指定“只重写 `SKILL.md`”。

### 步骤一 · 解析目标和模式

确认目标 skill 的目录、模式和修改边界。重写模式读取目标目录中的全部文件，并为每个文件决定保留、改写、删除或新增；其他模式按当前任务读取相关文件。依赖只读检查，除非用户明确把依赖也纳入范围。

完成条件：

- 结果条件：目标目录、模式和允许修改的文件范围已经明确。
- 覆盖条件（需要时）：重写模式下目标目录的每个文件都有处理决定；其他模式下每个相关引用都有读取结果或未读取原因。

### 步骤二 · 选择并执行模式

按用户意图选择一个模式：审计只读取和报告；重写先审计并提出方向，确认后重写；修补只改已接受的问题并复审；新建从目标、触发边界和权限范围开始设计。需要通用写作规则时读取可用的 `writing-for-agents/SKILL.md`，需要调用机制时读取 `SKILL-MECHANICS.md`；需要开放式设计取舍时才使用 `grilling`。

完成条件：

- 结果条件：当前模式的交付物已经产生，且没有把另一种模式的行为混入本次任务。
- 覆盖条件（需要时）：模式中的每个分支都已执行，或已记录具体的未决原因。

### 步骤三 · 编写或修补 skill

使用本目录的 `assets/SKILL-template.md` 组织新建或重写的入口文件，并按 `assets/SKILL-STRUCTURE.md` 分配目录内容。将共有步骤放在主文件，将只在特定模式需要的规则放到引用文件；每个步骤写动作正文和可被证伪的完成条件。新建、重写和修补时读取目标 skill 的 `log/decision-tree.md`；新建时按 `assets/decision-tree.md` 初始化，其他两种模式在原有决策树上更新，每轮确定后立即写入。

完成条件：

- 结果条件：frontmatter、主流程、引用指针和宿主配置与目标模式一致。
- 覆盖条件（需要时）：旧内容的每个章节都有保留、改写或删除的明确落点，且没有占位符或悬空引用。

### 步骤四 · 校验和复审

先做机械校验，再按 `references/audit-questions.md` 逐条标记 19 问。审计模式只输出结果；重写、修补和新建模式在写入后重新检查受影响的问题，并报告仍未解决的限制。

完成条件：

- 结果条件：必需文件、frontmatter、路径引用、调用策略和资源结构全部有明确结果。
- 覆盖条件：19 个问题全部标记，每个 `⚠️` 或 `❌` 都有证据、修复结果或未决原因。

## Rules

1. 审计模式保持只读；任何修改都属于重写或修补，必须由用户明确要求或确认。
2. 每个含义保留一个权威来源，环境中可以廉价查到的事实不复制进 skill。
3. 用正向目标描述行为；只有无法正向表达的硬护栏才使用禁令，并同时写出期望行为。
4. 只保留会改变 agent 决策或验证结果的内容，删除纯背景、重复说明和无效指令。

## References

- `references/audit-questions.md`：19 问审计清单。审计、重写、修补和新建完成前都读取并逐项复核。
- 可用的 `writing-for-agents/SKILL.md`：通用 agent 文档写作规则。
- 可用的 `writing-for-agents/SKILL-MECHANICS.md`：skill 的调用机制。
- `assets/SKILL-template.md`：skill 入口模板。新建或重写入口文件时读取。
- `assets/SKILL-STRUCTURE.md`：skill 目录结构和各类文件的职责。创建或重写目录时读取。
- `assets/decision-tree.md`：决策树模板。新建时初始化目标 skill 的 `log/decision-tree.md`，重写和修补时用于保持格式一致。
- `MANIFEST.md`：依赖和安装约定。需要检查依赖或安装布局时读取。
