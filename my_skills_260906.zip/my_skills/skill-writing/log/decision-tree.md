# 决策树 · skill-writing

**输出目录**：`skill-writing/`
**日期**：2026-09-06

## Tree

```text
├─ 1 通用范围 [→ Goal]
│    skill-writing 面向通用 agent skill 的创建、重写、审计和修补，不绑定某个宿主。
│
├─ 2 决策记录 [→ Output / Workflow]
│    新建、重写和修补都保留目标 skill 的 log/decision-tree.md，作为后续维护的长期上下文；审计只读。
│
└─ 3 目录职责 [→ References]
     主指令、引用、素材、脚本、宿主配置和决策记录按目录分工，避免把条件性内容堆进 SKILL.md。
```

## Facts

| # | 事实 | 来源 |
|---|---|---|
| F1 | skill 的宿主配置可能存在于 `agents/`，其文件名和字段由宿主决定。 | skill-writing 自身约定 |

## 未决项

| # | 项目 | 阻塞原因 | 处理方式 |
|---|---|---|---|
| | | | |
