# Skill 目录结构

```text
<skill-name>/
├─ SKILL.md                 # 必需：agent 读取的主指令
├─ agents/
│  └─ <host-config>         # 可选：宿主界面和调用策略配置
├─ references/              # 可选：按分支读取的规则、格式和事实
├─ assets/                  # 可选：生成结果需要复制或使用的模板、图片和素材
├─ scripts/                 # 可选：需要重复执行的确定性脚本
└─ log/
   └─ decision-tree.md      # 必需：新建、重写和修补的长期决策记录
```

`log/decision-tree.md` 是新建、重写和修补 skill 的必需记录；审计模式只读取，不创建或修改。`agents/` 是可选的宿主配置目录，文件名和字段由宿主决定。

