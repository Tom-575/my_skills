# MANIFEST

## 组成与依赖

安装时，将当前 skill 和其依赖放在同一个 skill 根目录下：

| 依赖 | 使用位置 |
| --- | --- |
| `skill-writing` | 当前 skill |
| `grilling` | 需要用户裁决未定设计问题时 |
| `writing-for-agents` | 创建、重写或修补 skill 时；其中的 `SKILL-MECHANICS.md` 用于调用方式和路由器规则 |

`grilling` 和 `writing-for-agents` 必须可被当前宿主调用。`log/decision-tree.md` 是新建、重写和修补目标 skill 的必需长期记录；审计模式只读取，不创建或修改。

## 安装约定

安装操作应保持幂等：如果目标位置已经存在 `<name>/SKILL.md`，就跳过该 skill，不覆盖现有副本。现有副本可能包含用户自己的修改。

不要额外嵌套一层 `skills/` 目录。平台按 `<skill-root>/<skill-name>/SKILL.md` 查找 skill，额外嵌套会导致目录无法被发现。

## 宿主差异

如果目标宿主要求额外字段，按该宿主的规范补充到宿主配置中；通用 skill 的 frontmatter 保持不变。除非用户明确指定宿主，不要把某个宿主的字段写入通用 skill。

