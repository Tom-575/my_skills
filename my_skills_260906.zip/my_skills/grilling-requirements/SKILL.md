---
name: grilling-requirements
description: Clarify software requirements through structured questioning and record the agreed scope, rules, and acceptance criteria. Use before implementation when requirements are ambiguous or conflicting.
---

# grilling-requirements

## Goal

- 将想法、会议纪要或 PRD 草稿整理成可审核的需求澄清文档。
- 只澄清和记录，不替用户做业务取舍；下游仅消费已审核的文档。

## Input

- 需求描述、会议纪要、PRD 草稿或其他背景材料。
- 输出目录；未提供时，第一轮问题前询问。

## Output

- 输出目录中的 `CLARIFICATION.md`，包含 Tree、Facts、我的建议和待裁决清单。
- 文档头部使用 `status: draft | reviewed`；只有 `reviewed` 才能交给需求文档或 `to-spec`。
- 目标 skill 的 `log/decision-tree.md`，记录本次需求澄清的长期决策上下文。

## Workflow

### 步骤一 · 整理输入

读取用户提供的材料，整理术语、事实、现状和约束，并将来源写入 Facts。识别材料中的矛盾和歧义，作为首轮问题；如果范围明显超过一次会话，建议转交多会话规划流程并停止本流程，保留当前决策记录。

完成条件：

- 结果条件：`CLARIFICATION.md` 已建立草稿结构，输入材料中的可用信息已归档到对应分区。
- 覆盖条件：每条已归档事实都有来源，每个发现的矛盾或歧义都进入首轮问题。

### 步骤二 · 运行分轮澄清

按 `grilling-to-doc` 的前沿规则分轮提问，并读取 `references/dimensions.md` 组织首轮问题。每轮回答后按 `references/templates.md` 更新 `CLARIFICATION.md` 和 `log/decision-tree.md`，将建议集中放在“我的建议”，将未决事项集中放在待裁决清单。

完成条件：

- 结果条件：每轮问题只依赖已确定的前置答案，并在下一轮开始前写入本轮结果。
- 覆盖条件：常驻字段、触发出的临时分支和用户提出的新增问题都已处理或记录为未决。

### 步骤三 · 审核并交付

当决策前沿为空且待裁决项已清零，或用户明确接受剩余的 `[ASSUME]` / `[BLOCKED]` 项时，将状态改为 `reviewed`。通读文档，检查 Tree、Facts、建议和待裁决清单的一致性，再向用户交付。

完成条件：

- 结果条件：`CLARIFICATION.md` 的状态、内容和引用关系一致，下游可以据此判断是否允许消费。
- 覆盖条件：所有事实、决策、建议和未决项都有明确状态，且每个 Tree 节点引用的事实都存在。

## Rules

1. 用户确认前，材料中的陈述保持待确认状态，不自动升格为事实。
2. 建议只放在“我的建议”，不得混入 Facts 或 Tree。
3. `reviewed` 是下游消费门禁；审核后的实质改动将状态恢复为 `draft`。

## References

- `references/templates.md`：`CLARIFICATION.md` 的格式、状态和字段规则。写入或更新澄清文档时读取。
- `references/dimensions.md`：首轮字段、触发分支和原型转交规则。组织首轮问题时读取。
- 可用的 `grilling-to-doc`：分轮前沿、决策记录和冲突处理流程。开始澄清会话时读取。
